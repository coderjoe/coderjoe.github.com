// AwesomeTankGame.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

LRESULT CALLBACK GlobalWinProc( HWND hWnd,
								UINT uMsg,
								WPARAM wParam,
								LPARAM lParam )
{
	PAINTSTRUCT ps;
	HDC hdc;

	switch( uMsg )
	{
	case WM_CREATE:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
		break;

	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		EndPaint(hWnd, &ps);
		break;
	
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
		
	default:
		return DefWindowProc(hWnd, uMsg,wParam,lParam);

	}

	return 0;
}

int APIENTRY WinMain( HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPSTR lpCmdLine,
					int nShowCmd )
{
	LPCTSTR sWinClass = _T("Awesome Tank Game");
	WNDCLASSEX wc;

	wc.cbSize = sizeof( WNDCLASSEX );
	wc.style = CS_CLASSDC;
	wc.lpfnWndProc = GlobalWinProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = DLGWINDOWEXTRA;
	wc.hInstance = hInstance;
	wc.hIcon = NULL;
	wc.hCursor = NULL;
	wc.hbrBackground = (HBRUSH) GetStockObject( BLACK_BRUSH );
	wc.lpszMenuName = NULL;
	wc.lpszClassName = sWinClass;
	wc.hIconSm = NULL;

	RegisterClassEx( &wc );

	HWND hWnd = CreateWindow(
					sWinClass,
					sWinClass,
					WS_OVERLAPPEDWINDOW,
					100, // x loc
					100, // y loc
					640, // window width
					480, // window height
					NULL,
					NULL,
					hInstance,
					NULL );

	if( ! hWnd ) {
		return E_FAIL;
	}

	ShowWindow(hWnd, nShowCmd );
	UpdateWindow(hWnd);

	MSG msg;
	while(TRUE) {

		if ( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) ) {

			if(msg.message == WM_QUIT ) {
				break;
			}

			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}

		// render loop here
	}

	return msg.wParam;
}
