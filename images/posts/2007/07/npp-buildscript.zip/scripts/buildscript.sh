TEST=`pwd | grep "source"`
MAKEPATH=`pwd | sed 's/\(.\+\)source.*/\1/g'`

cd ${MAKEPATH}

if [ -n "$TEST" ]; then
	make $1
else
	echo "Not compiling! $MAKEPATH is not a project source directory!"
fi

exit 0