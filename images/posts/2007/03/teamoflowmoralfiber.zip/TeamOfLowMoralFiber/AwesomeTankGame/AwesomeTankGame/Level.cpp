#include "stdafx.h"
#include "Level.h"

Level::Level( std::string filename ) {
	//init values
	m_enemyLayer = 0; 
	m_playerLayer = 0;

	//open the mapfile
	std::ifstream mapfile;
	mapfile.open( filename.c_str() );

	std::string keyword;
	std::string loadFile;

	while( !mapfile.eof() ) {
		mapfile >> keyword;
		//if we are spawning a layer
		if( keyword == "LAYER" ) {
			mapfile >> loadFile;
			m_mapLayers.push_back( new LevelMap( loadFile ) ); //add it to our layers
		}

		//if we're spawning an actor
		if( keyword == "ACTORS" ) {
			mapfile >> loadFile;
			m_actorFiles.push_back( new LevelActors( loadFile ) ); //spawn it and store it
			m_enemyLayer = m_mapLayers.size() - 1;
		}

		//if we're spawning a player
		if( keyword == "PLAYER" ) {
			m_playerLayer = m_mapLayers.size() - 1; //store the location for later
		}
	}
}

Level::~Level() {
	//destroy all our memory so we're not lossy
	for( int i = m_mapLayers.size()-1; i >= 0; i-- ) {
		LevelMap * temp;
		temp = m_mapLayers[i];
		m_mapLayers.pop_back();
		delete temp;
		temp = NULL;
	}
}

void Level::tick() {
	//tick throught he actors and players
	for( int i = 0; i < m_actorFiles.size(); i++ ) {
		m_actorFiles[i]->tick();
	}

	for( int i = 0; i < m_mapLayers.size(); i++) {
		m_mapLayers[i]->tick();
	}
}

void Level::drawBelow() {
	//draw stuff below the player
	for( int i = 0; i <= m_playerLayer && i < m_mapLayers.size(); i++ ) {
		m_mapLayers[i]->draw();
	}
}

void Level::drawAbove() {
	//draw stuff above the player
	for( int i = m_playerLayer+1; i < m_mapLayers.size(); i++ ) {
		m_mapLayers[i]->draw();
	}
}

int Level::getSpeed() {
	//get the speed below the player
	return m_mapLayers[m_playerLayer]->getSpeed();
}