#ifndef _FONTMANAGER_H_
#define _FONTMANAGER_H_

#include <string>
#include "d3dx9.h"
#include "D3DManager.h"
#include "TextureManager.h"
#include "GFXManager.h"
#include "singleton.h"

#define FONTMANAGER FontManager::Instance()

// Draws text on the screen.  very useful.
class FontManager : public Singleton<FontManager> {
	friend class Singleton<FontManager>;
protected:
	FontManager();
	~FontManager();
public:
	// Draw at location, with font map, color, and dimensions
	void draw( int texture, std::string text, float x, float y, D3DCOLOR color = -1, float w = 0.0, float h = 0.0 );
private:
	void asciiToIndex( char c , int & x, int & y);

	int		m_charsPerRow;
	int		m_charsPerCol;
	int		m_indexStartPos;
};

#endif