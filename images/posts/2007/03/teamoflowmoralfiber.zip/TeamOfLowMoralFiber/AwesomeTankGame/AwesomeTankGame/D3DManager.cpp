#include "stdafx.h"
#include "D3DManager.h"

D3DManager::D3DManager() 
: m_hWnd( GAMEWINDOW.hWnd() ), m_pd3ddevice( NULL ), m_bInitialized(false) {

	m_pd3d = Direct3DCreate9( D3D_SDK_VERSION );
	
	m_pd3d->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &m_d3ddm );

	//default display parameters
	m_width = 640;
	m_height = 480;
	m_fullscreen = false;
	m_d3dfmt = m_d3ddm.Format;
}

D3DManager::~D3DManager() {
	releaseDevice();

	if( m_pd3d ) {
		m_pd3d->Release();
		m_pd3d = NULL;
	}
}

void D3DManager::setVideoSize( int w, int h ) {
	m_width = w;
	m_height = h;
}

void D3DManager::setFormat( D3DFORMAT d3dfmt ) {
	m_d3dfmt = d3dfmt;
}

void D3DManager::setFullScreen( bool fullscreen ) {
	m_fullscreen = fullscreen;
}

bool D3DManager::getFullScreen() {
	return m_fullscreen;
}

void D3DManager::toggleFullScreen(){
	setFullScreen( ! getFullScreen() );
	releaseDevice();
	initDevice();
}

bool D3DManager::initDevice() {
	HRESULT hr;

	if( m_bInitialized ) {
		releaseDevice();
	}

	ZeroMemory( &m_d3dpp, sizeof( D3DPRESENT_PARAMETERS ) );

	// set up buffer
	m_d3dpp.BackBufferCount = 1;
	m_d3dpp.BackBufferFormat = m_fullscreen ? m_d3dfmt : m_d3ddm.Format;
	m_d3dpp.BackBufferWidth = m_width;
	m_d3dpp.BackBufferHeight = m_height;
	m_d3dpp.Windowed = !m_fullscreen;
	
	// No multisampling
	m_d3dpp.MultiSampleType = D3DMULTISAMPLE_NONE;
	m_d3dpp.MultiSampleQuality = 0;

	m_d3dpp.SwapEffect = D3DSWAPEFFECT_FLIP;
	m_d3dpp.hDeviceWindow = m_hWnd;
	m_d3dpp.Flags = 0;
	m_d3dpp.FullScreen_RefreshRateInHz = D3DPRESENT_RATE_DEFAULT;
	m_d3dpp.PresentationInterval = D3DPRESENT_INTERVAL_ONE;

	m_d3dpp.EnableAutoDepthStencil = TRUE;
	m_d3dpp.AutoDepthStencilFormat = D3DFMT_D16;

	if( m_d3dpp.Windowed ) {
		// Update the windowed size based on the new D3D sizes.
		SetWindowPos( 
					m_hWnd, 
					HWND_TOP,
					0, 
					0, 
					m_width, 
					m_height,
					SWP_NOMOVE | SWP_NOOWNERZORDER | SWP_NOZORDER
					);
	}

	hr = m_pd3d->CreateDevice( 
					D3DADAPTER_DEFAULT,
					D3DDEVTYPE_HAL,
					m_hWnd,
					D3DCREATE_HARDWARE_VERTEXPROCESSING,
					&m_d3dpp,
					&m_pd3ddevice
					);
					
	if( SUCCEEDED( hr ) ) {
		m_bInitialized = true;
	} else {
		//return false;
	} 

	return true;
}

void D3DManager::releaseDevice() {
	if( m_pd3ddevice ) {
		m_bInitialized = false;
		m_pd3ddevice->Release();
		m_pd3ddevice = NULL;
	}
}

LPDIRECT3D9 & D3DManager::getD3D() {
	return m_pd3d;
}

LPDIRECT3DDEVICE9 & D3DManager::getDevice() {
	return m_pd3ddevice;
}

bool D3DManager::isInitialized() {
	return m_bInitialized;
}

int D3DManager::getWidth() {
	return m_width;
}

int D3DManager::getHeight() {
	return m_height;
}