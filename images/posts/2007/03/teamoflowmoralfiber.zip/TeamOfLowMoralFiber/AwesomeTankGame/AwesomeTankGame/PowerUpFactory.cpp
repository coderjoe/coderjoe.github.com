#include "stdafx.h"
#include "PowerUpFactory.h"
#include "FontManager.h"
#include "Powerup.h"
#include "GameEngine.h"

void PowerUpFactory::CreatePowerUpAt( int x, int y ) {
	//get our random modifier
	int power = rand() % 70;
	
	//get an actor to spawn
	Actor * myActor = NULL;

	switch( power ) {
		case 7:
			//speed
			myActor = new Powerup( speed, x, y );
			break;
		case 22:
			//fire
			myActor = new Powerup( fire, x, y );
			break;
		case 14:
			//tri fire
			myActor = new Powerup( tri, x, y );
			break;
		case 1:
			//laser
			myActor = new Powerup( laser, x, y );
			break;
		default:
			myActor = NULL;
			break;
	}

	//spawn the actor
	if( myActor != NULL ){
		GAMEENGINE.addActor( myActor );
	}
}