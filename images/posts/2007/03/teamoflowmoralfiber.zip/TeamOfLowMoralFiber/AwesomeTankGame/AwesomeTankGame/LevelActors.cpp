#include "stdafx.h"
#include "GameEngine.h"
#include "LevelActors.h"
#include "ActorFactory.h"

LevelActors::LevelActors( std::string filename ) {
	m_iInterval = 0;
	std::ifstream file;
	file.open( filename.c_str() );

	std::string keyword;
	std::string name;
	int			y;
	int			x;
	int			interval;

	//while the file is not done processing
	while( !file.eof() ) {
		file >> keyword;

		//if we're an interval
		if( keyword == "INTERVAL" ) {
			file >> interval;
			//make a new interval
			m_vIntervals.push_back( IntervalInfo( interval ) );
		}

		//process an actor
		if( keyword == "ACTOR" ) {
			file >> name; //name
			file >> x;	//x y position
			file >> y;

			//add to the interval
			if( m_vIntervals.size() > 0 ) {
				m_vIntervals[m_vIntervals.size()-1].actors.push_back( ActorInfo( name, x, y ) );
			}
		}
	}
}

LevelActors::~LevelActors() {
}

void LevelActors::tick() {
	//tick through the actors
	if( (int)m_vIntervals.size() > 0  && m_iInterval < (int)m_vIntervals.size() ) {
		m_vIntervals[m_iInterval].interval--; //decrement the interval if we aren't done yet

		//if the interval is 0, we need to spin through the actors and spawn
		if( m_vIntervals[m_iInterval].interval <= 0 ) {
			//spawn all the enemies
			for( unsigned int i = 0; i < m_vIntervals[m_iInterval].actors.size(); i++ ) {

				//create the actors from the factory
				Actor * a = ActorFactory::CreateActorAt(
									m_vIntervals[m_iInterval].actors[i].name,
									m_vIntervals[m_iInterval].actors[i].x,
									m_vIntervals[m_iInterval].actors[i].y
									);
				if( a ) {
					//add them to the game
					GAMEENGINE.addActor( a );
				}
			}
			//move to the next interval
			m_vIntervals[m_iInterval].reset();
			m_iInterval = static_cast<int>((m_iInterval + 1) % m_vIntervals.size());
		}
	}
}