#include "stdafx.h"
#include "GameEngine.h"
#include "GFXManager.h"
#include "FontManager.h"
#include "SoundManager.h"
#include "TestEnemy.h"
#include "TestEnemyLeft.h"
#include "Helicopter.h"
#include "HelicopterLeft.h"
#include "StationaryTurret.h"
#include "HorizontalTank.h"
#include "HorizontalTankLeft.h"
#include "VerticalBike.h"
#include <algorithm>
#include "Laser.h"



GameEngine::GameEngine(){
	// Initialize things to defaults
	m_powerup = NULL;

	score = 0;
	multiplier = 1;
	killCounter = 0;
	m_startedPlaying = false;
	m_died = false;
	m_paused = false;
	srand( clock() );
}

GameEngine::~GameEngine() {
	
}

void GameEngine::tick(){
	if( ! m_paused && m_startedPlaying ) {
		// Clear the bins
		for( int i = 0; i < BIN_WIDTH; i++ ){
			for( int k = 0; k < BIN_HEIGHT; k++ ){
				friendBins[i][k].clear();
				foeBins[i][k].clear();
				neutralBins[i][k].clear();
			}
		}

		// Tick the actors
		for( unsigned int i = 0; i < friendlies.size(); friendlies[i++]->tick() );
		for( unsigned int i = 0; i < foes.size(); foes[i++]->tick() );
		for( unsigned int i = 0; i < neutrals.size(); neutrals[i++]->tick() );
		m_pLevel->tick();

		
		// Run Collision detection
		for( int i = 0; i < BIN_WIDTH; i++ ){
			for( int k = 0; k < BIN_HEIGHT; k++ ){
				if( (foeBins[i][k].size() > 0 || neutralBins[i][k].size() > 0) && friendBins[i][k].size() > 0 ){
					for( unsigned int m = 0; m < friendBins[i][k].size(); m++ ){
						friendBins[i][k][m]->collide( foeBins[i][k] );
						friendBins[i][k][m]->collide( neutralBins[i][k] );
					}
					for( unsigned int m = 0; m < foeBins[i][k].size(); m++ ){
						foeBins[i][k][m]->collide( neutralBins[i][k] );
					}
				}
			}
		}
	}

	// death stuff
	if( m_died ) {
		m_youDiedMenu->tick();
	}
	
	// tick FMOD
	SOUNDMANAGER.getSystem()->update();

	// Misc. operations
	if( INPUTMANAGER.IsKeyDown( DIK_ESCAPE ) ) {
		quitGame();
	}

	// Run the input
	if( INPUTMANAGER.IsKeyDown( DIK_F ) ) {
		TEXTUREMANAGER.killTextures();
		GFXMANAGER.killSprite();
		D3DMANAGER.toggleFullScreen();
		TEXTUREMANAGER.loadTextures();
		GFXMANAGER.initSprite();
	}

	clock_t now = clock();
	if( m_startedPlaying && !m_died && INPUTMANAGER.IsKeyDown( DIK_P ) && (now - m_lastPause) > 200 ) {
		m_paused = !m_paused;
		m_lastPause = clock();
	}
}

void GameEngine::draw(){
	INPUTMANAGER.UpdateMousePosition();
	/*std::stringstream sStream;

	sStream << "Frame Rate: " << STATISTICS.getFrameRate() << "\nPress 'F' to toggle windowed/fullscreen\nPress ESC to quit\n" << (char)((int)'~'+1);
	std::string frameRateString( sStream.str() );*/

	STATISTICS.calculateFrameRate();


	/*std::stringstream debug;
	debug << "+ " << friendlies.size() << "    - " << foes.size() << "    = " << neutrals.size();
	std::string debugString( debug.str() );*/

	if( D3DMANAGER.getDevice()->BeginScene() ) {
		//D3DMANAGER.getDevice()->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_XRGB( 150 ,150, 150 ), 1.0f, 0);
		GFXMANAGER.begin();

		// Draw the mouse
		int x, y;
		INPUTMANAGER.MouseCurrentPosition( x, y);
		D3DXVECTOR2 mousePos;
		mousePos.x = static_cast<float>(x) - m_mouseCenter.x;
		mousePos.y = static_cast<float>(y) - m_mouseCenter.y;

		// if in the game
		if( m_startedPlaying ) {

			m_pLevel->drawBelow();

			// Draw the actors
			for( unsigned int i = 0; i < neutrals.size(); neutrals[i++]->draw() );
			for( unsigned int i = 0; i < foes.size(); i++ ){if( foes[i]->getObjectType()==ground_enemy) foes[i]->draw(); }
			for( unsigned int i = 0; i < foes.size(); i++ ){if( foes[i]->getObjectType()!= ground_enemy) foes[i]->draw(); }
			for( unsigned int i = 0; i < friendlies.size(); friendlies[i++]->draw() );
			
			m_pLevel->drawAbove();

			//Draw death scren if necessary
			if( m_died ) {
				m_youDiedMenu->draw();
			}

			// Debug stuff
			/*
			for( int i = 0; i < BIN_WIDTH; i++ ){
				for( int k = 0; k < BIN_HEIGHT; k++ ){
					int fo = foeBins[i][k].size();
				int fr = friendBins[i][k].size();
				int ne = neutralBins[i][k].size();
				char temp[20];
					itoa(friendBins[i][k].size()+neutralBins[i][k].size()+foeBins[i][k].size(),temp,10);
					FONTMANAGER.draw(TEX_FONT_FUTURA,temp , 128*i,128*k,D3DCOLOR_XRGB(0,0,255));
				}
			}
			FONTMANAGER.draw( TEX_FONT_FUTURA, debugString, 10, 140 );
			FONTMANAGER.draw( TEX_FONT_FUTURA, frameRateString, 12, 12, D3DCOLOR_ARGB( 170,  0, 0, 0 ) );
			FONTMANAGER.draw( TEX_FONT_FUTURA, frameRateString, 10, 10, D3DCOLOR_XRGB( 255, 0, 0 ) );
			*/
			//FONTMANAGER.draw( TEX_FONT_FUTURA, scoreString, 100, 30, D3DCOLOR_XRGB( 0, 255, 0) );

			GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_MOUSE_CURSOR ), 0, &m_mouseCenter, &mousePos );

			drawUI();

		} else if( !m_startedPlaying && !m_died ) {
			m_mainMenu->tick();
			m_mainMenu->draw();

			GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_MOUSE_CURSOR ), 0, &m_mouseCenter, &mousePos );
		}


		//Draw pause if necessary
		if( m_paused ) {
			GFXMANAGER.draw( TEXTUREMANAGER.getTexture(TEX_TINY_WHITE), NULL,NULL,
				NULL,&D3DXVECTOR2(DEFAULT_WIDTH, DEFAULT_HEIGHT),0,D3DXCOLOR(0,0,0,.4));
			FONTMANAGER.draw( TEX_FONT_FUTURA, "PAUSE", (GAME_WIDTH/2)-45, GAME_HEIGHT/2, D3DCOLOR_ARGB( 170, 0, 0, 0 ) );
			FONTMANAGER.draw( TEX_FONT_FUTURA, "PAUSE", (GAME_WIDTH/2)-48, (GAME_HEIGHT/2)-3, D3DCOLOR_XRGB( 255, 255, 0 ) );
		}

		GFXMANAGER.end();

		D3DMANAGER.getDevice()->EndScene();
	};
	D3DMANAGER.getDevice()->Present( NULL, NULL, NULL, NULL );
}

void GameEngine::drawUI(){
	char tmp[9];
	
	// draw hud
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture(TEX_HUD_BASE), NULL, NULL, &D3DXVECTOR2(824, 0), NULL, 0);
	
	// draw scorer/multiplier
	sprintf( tmp, "%8d", score ); 
	FONTMANAGER.draw( TEX_FONT_FUTURA, tmp, 842, 211, D3DCOLOR_XRGB( 0, 0, 0) );
	sprintf( tmp, "%d", multiplier );
	FONTMANAGER.draw( TEX_FONT_FUTURA, tmp, 906, 698, D3DCOLOR_XRGB( 0, 0, 0), 1.7, 1.7 );
	
	// Draw the multiplier bar
	float bar_scale = (static_cast<float>(killCounter) / MULTIPLIER_INTERVAL);
	float bar_top = 680 -(bar_scale * 264 );
	
	D3DXCOLOR bar_color;
	switch( multiplier ){
		case 1:
			bar_color = D3DCOLOR_XRGB(56, 180, 255);
			break;
		case 2:
			bar_color = D3DCOLOR_XRGB(179, 0, 0);
			break;
		case 3:
			bar_color = D3DCOLOR_XRGB(147, 255, 199);
			break;
		case 4:
			bar_color = D3DCOLOR_XRGB(255, 255, 255);
			break;
	}

	// draw the active powerup
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture(TEX_HUD_MULTIPLIER), NULL, NULL, &D3DXVECTOR2(917, bar_top), &D3DXVECTOR2(1.0, bar_scale), 0, bar_color );
	if( m_powerup != NULL ){
		m_powerup->draw();
	}
}

void GameEngine::init( HINSTANCE hInstance ){
	//initialize all that windows and d3d stuff
	m_hInstance = hInstance;
	GAMEWINDOW.setupWindow( hInstance );
	GAMEWINDOW.createWindow();

	D3DMANAGER.setVideoSize( DEFAULT_WIDTH, DEFAULT_HEIGHT );
	D3DMANAGER.setFormat( DEFAULT_D3DFMT );
	D3DMANAGER.setFullScreen( DEFAULT_FULLSCREEN );

	D3DMANAGER.initDevice();

	initKeyboard();

	TEXTUREMANAGER.loadTextures();

	//Initialize the mouse center location
	m_mouseCenter.x = (float)TEXTUREMANAGER.getTextureInfo( TEX_MOUSE_CURSOR ).Width / 2;
	m_mouseCenter.y = (float)TEXTUREMANAGER.getTextureInfo( TEX_MOUSE_CURSOR ).Height / 2;

	// play the theme!
	SOUNDMANAGER.Play( "sounds/theme.mp3", true );

	m_mainMenu = new MainMenu();
	m_youDiedMenu = new YouDiedMenu();
}

void GameEngine::initKeyboard() {
	INPUTMANAGER.SetupInputDevices();
}

void GameEngine::killKeyboard() {
	INPUTMANAGER.ReleaseInputDevices();
}


void GameEngine::registerCollidable(Collidable *coll){
	// find out where the actor is
	static float binsize = DEFAULT_HEIGHT / BIN_HEIGHT;
	std::vector<D3DXVECTOR2> points = coll->getPoints();
	

	float xmin = GAME_WIDTH+1;
	float xmax = -1;
	float ymax = -1;
	float ymin = DEFAULT_HEIGHT+1;
	D3DXVECTOR2 pos = coll->getPosition();

	for( unsigned int i = 0; i < points.size(); i++ ){
		xmin = min(xmin, points[i].x + pos.x);
		ymin = min(ymin, points[i].y + pos.y);
		xmax = max(xmax, points[i].x+ pos.x);
		ymax = max(ymax, points[i].y + pos.y);
	}
	
	xmax /= binsize;
	xmin /= binsize;
	ymax /= binsize;
	ymin /= binsize;

	xmin = (xmin < 0)?0:xmin;
	ymin = (ymin < 0)?0:ymin;
	xmax = (xmax >= BIN_WIDTH)?BIN_WIDTH-1:xmax;
	ymax = (ymax >= BIN_HEIGHT)?BIN_HEIGHT-1:ymax;

	// Now that we know what bins the thing is in, add it to the correct one based on type

	for( int i = (int)xmin; i <= xmax; ++i ){
		for( int k = (int)ymin; k <= ymax; ++k ){
			switch(coll->getType()){
				case friendly:
					friendBins[i][k].push_back(coll);
					break;
				case foe:
					foeBins[i][k].push_back(coll);
					break;
				case neutral:
					neutralBins[i][k].push_back(coll);
					break;
			}
		}
	}
}

void GameEngine::addActor( Actor* act ){
	// add to tick bin based on type
	switch(act->getType()){
		case friendly:
			friendlies.push_back(act);
			break;
		case foe:
			foes.push_back(act);
			break;
		case neutral:
			neutrals.push_back(act);
			break;
	}
}

void GameEngine::removeActor(Actor *act){
	switch(act->getType()){
		case friendly:
			friendlies.erase(std::remove(friendlies.begin(), friendlies.end(), act ), friendlies.end());
			break;
		case foe:
			foes.erase(std::remove(foes.begin(), foes.end(), act ), foes.end());
			break;
		case neutral:
			neutrals.erase(std::remove(neutrals.begin(), neutrals.end(), act ), neutrals.end());
			break;
	}
	delete act;
	act = NULL;
}

void GameEngine::clearActors() {
	std::vector<Actor*>::iterator actorIter;
	Actor * actor;
	while( friendlies.size() > 0 ) {
		actor = friendlies[0];
		friendlies.erase(friendlies.begin());
		delete actor;
		actor = NULL;
	}

	while( foes.size() > 0 ) {
		actor = foes[0];
		foes.erase( foes.begin() );
		delete actor;
		actor = NULL;
	}

	while( neutrals.size() > 0 ) {
		actor = neutrals[0];
		neutrals.erase( neutrals.begin() );
		delete actor;
		actor = NULL;
	}
}

Tank* GameEngine::getTank(){
	// run through friendly things to find the tak and return it.
	for( unsigned int i = 0; i < friendlies.size(); ++i ){
		if( friendlies[i]->getObjectType() == tank )
			return dynamic_cast<Tank*>(friendlies[i]);
	}
	return NULL;
}
void GameEngine::updateScore( int increase ){
	// only update score if not dead.
	if( ! m_died ) {
		if( increase < 0 ){
			multiplier = 1;
			killCounter = 0;
		} else if ( multiplier < 4 ){
			killCounter++;
			if( killCounter > MULTIPLIER_INTERVAL ){
				multiplier++;
				if( multiplier != 4 && killCounter > MULTIPLIER_INTERVAL ) {
					killCounter %= MULTIPLIER_INTERVAL;
				} else if( multiplier == 4 && killCounter > MULTIPLIER_INTERVAL ){
					killCounter = MULTIPLIER_INTERVAL;
				}
			}
		}

		score = score + (increase * multiplier);
	}
}

int GameEngine::getScore(){
	return score;
}

void GameEngine::setPowerup( powerup_t ptype ){
	if( m_powerup != NULL ) {
		removeActor( m_powerup );
		m_powerup = NULL;
	} 
	if( ptype != none ){
		m_powerup = new Powerup( ptype, 899, 335 );
		m_powerup->setDy(0);
		addActor( m_powerup );
	}
}


void GameEngine::startGame() {

	// initialize all game defaults
	multiplier = 1;
	killCounter = 0;
	score = 0;
	clearActors();
	m_powerup = NULL;

	if( m_pLevel ) {
		delete m_pLevel;
	}
	m_pLevel = new Level( "maps/level1.txt" );

	Tank * tank = new Tank();
	tank->setPosition( ( GAME_WIDTH / 2 ) - ( tank->getWidth() / 2 ), 
					   GAME_HEIGHT - tank->getHeight() );
	addActor(tank);

	m_startedPlaying = true;
	m_died = false;
	m_paused = false;
}

void GameEngine::restartGame() {
	startGame();
}

void GameEngine::endGame() {
	m_died = true;
}

void GameEngine::quitGame() {
	PostQuitMessage( 0 );
}

bool GameEngine::isDead() {
	return m_died;
}

Level * GameEngine::getLevel() {
	return m_pLevel;
}