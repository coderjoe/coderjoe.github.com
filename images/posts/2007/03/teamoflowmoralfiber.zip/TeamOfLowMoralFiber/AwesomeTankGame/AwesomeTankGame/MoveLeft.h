#ifndef _MOVELEFT_H_
#define _MOVELEFT_H_

#include "Movement.h"
#include "Collidable.h"

// Moves an object left at a given speed
class MoveLeft : public Movement {
public:
	MoveLeft( Collidable * obj, double speed );
	virtual ~MoveLeft();

	// performs the move
	virtual void move();
private:
};

#endif