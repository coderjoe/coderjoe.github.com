// AwesomeTankGame.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "GameEngine.h"
#include "SoundManager.h"

int APIENTRY WinMain( HINSTANCE hInstance,
					HINSTANCE hPrevInstance,
					LPSTR lpCmdLine,
					int nShowCmd )
{
	//Initialize our Game engine
	GAMEENGINE.init( hInstance );

	//SOUNDMANAGER.Play(_T("notify.wav"));
	
	MSG msg;
	while(TRUE) {

		if ( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) ) {

			if(msg.message == WM_QUIT ) {
				break;
			}

			TranslateMessage( &msg );
			DispatchMessage( &msg );
		}

		GAMEENGINE.tick();
		GAMEENGINE.draw();

	}

	return S_OK;
}
