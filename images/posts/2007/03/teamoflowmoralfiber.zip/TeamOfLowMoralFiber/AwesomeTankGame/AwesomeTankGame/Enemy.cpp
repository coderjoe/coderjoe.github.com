#include "stdafx.h"
#include "Enemy.h"
#include "GameEngine.h"
#include "Explosion.h"
#include "Bullet.h"
#include "SoundManager.h"
#include "PowerupFactory.h"

Enemy::Enemy(void)
{
	m_score = 50;
}

Enemy::~Enemy(void)
{
}

void Enemy::setCollided(Collidable *other){
	object_t otype = other->getObjectType();
	// decrement health when hit by bullets
	if( otype == fr_bullet  ){
		Bullet* bother = dynamic_cast<Bullet*>(other);
		m_health -= bother->getDamage();
	} 
	// Die when hit by player or laser.
	else if( otype == fr_laser || otype == tank) {
		m_health = 0;
	}

	// When dead, spawn an explosion and disappear
	if( m_health <= 0 ) {
		SOUNDMANAGER.Play( "sounds/object_explode5.wav", false, .6 );
		
		Explosion * explsn = new Explosion();
		explsn->setPosition( m_position.x, m_position.y );
		PowerUpFactory::CreatePowerUpAt(m_position.x, m_position.y);

		
		GAMEENGINE.addActor( explsn );
		GAMEENGINE.updateScore( m_score );
		collided = true;
		return;
	}
}