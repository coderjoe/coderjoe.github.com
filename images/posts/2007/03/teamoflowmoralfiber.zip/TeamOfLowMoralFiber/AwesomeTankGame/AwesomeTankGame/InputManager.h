/*
 * InputManager.h
 *
 * This file is a very simple wrapper around the DirectInput keyboard functionality
 * it provides a simple way to setup and release a keyboard binding, as well as a very simple
 * way to check if a keyboard key is pressed.
 *
 * NOTE: This code and the code in DKeyboard.cpp is based HEAVILY upon the DIKeyboard class from Professor 
 *			Phelp's 2dGameEngine example since I couldn't think of a better way to achieve the same result.
 */

#ifndef _INPUTMANAGER_H_
#define _INPUTMANAGER_H_

#include "dinput.h"
#include "D3DManager.h"
#include "GameWindow.h"
#include "Singleton.h"

#define INPUTMANAGER DInputManager::Instance()

class DInputManager : public Singleton<DInputManager> {
	friend class Singleton<DInputManager>;
protected:
	DInputManager();
	~DInputManager();
public:
	// Creation and destruction routines
	bool SetupInputDevices();
	void ReleaseInputDevices();
	
	// get mouse position
	bool UpdateMousePosition();
	bool MouseCurrentPosition(int & xPos, int & yPos);
	// Get input stuff, pretty simple
	bool MouseIsLeftDown();
	bool MouseIsRightDown();
	bool IsKeyDown( int key );
private:
	// storage for state
	char m_keys[256];
	POINT m_mouseLoc;
	DIMOUSESTATE mouse_state;

	// Device stuff, no touching
	LPDIRECTINPUT8 m_input;
	LPDIRECTINPUTDEVICE8 m_mouse;
	LPDIRECTINPUTDEVICE8 m_keyboard;
};

#endif