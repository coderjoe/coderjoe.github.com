#ifndef _GFXMANAGER_H_
#define _GFXMANAGER_H_

#include "Singleton.h"
#include "d3dx9.h"

#define GFXMANAGER GFXManager::Instance()

// A helper class for making things easier to draw, basically with a single call for drawing.
class GFXManager : public Singleton<GFXManager> {
	friend class Singleton<GFXManager>;
protected:
	GFXManager(void);
	~GFXManager(void);

public:
	// initialize and destroy stuff
	void initSprite();
	void killSprite();
	// begin and end the scene
	void begin();
	void end();
	// draw a sprite with all kinds of info.  the function handles all the hard bits of scaling and rotating
	void draw( LPDIRECT3DTEXTURE9 pTexture, 
				CONST RECT *pSrcRect = NULL, 
				CONST D3DXVECTOR2 *center = NULL,
				CONST D3DXVECTOR2 *pPosition = NULL,
				CONST D3DXVECTOR2 *pScaling = NULL,
				UINT rotation = 0,
				D3DCOLOR Color = 0xffffffff);


private:
	// The sprite we draw with
	LPD3DXSPRITE m_sprite;
};

#endif