#include "stdafx.h"
#include "StationaryTurret.h"
#include "D3DManager.h"
#include "SoundManager.h"
#include "GameEngine.h"
#include "Explosion.h"
#include "PowerUpFactory.h"
#include "EnemyBullet.h"

//Identifier for factory
const std::string StationaryTurret::IDENTIFIER = "STATIONARY_ENEMY";

StationaryTurret::StationaryTurret() {
	type = foe; //we are an enemy
	obj_type = ground_enemy; //which stays on the ground
	m_health = 4;
	m_score = 100;

	//set our speed based on the level scroll speed
	m_dy = GAMEENGINE.getLevel()->getSpeed();

	//set up our collision detection
	points.push_back(D3DXVECTOR2(5,5));
	points.push_back(D3DXVECTOR2(95,0));
	points.push_back(D3DXVECTOR2(95,95));
	points.push_back(D3DXVECTOR2(0,95));

	//calculate the base center and gun center
	// this is based on points from the image
	// if the image changes, this MUST change
	m_baseCenter.x = 48;
	m_baseCenter.y = 50;
	m_gunCenter.x = 48;
	m_gunCenter.y = 50;

	//set initial gun rotation (down)
	m_gunRotation = 0;
	//calculate the gun length based on the center and top
	m_gunLength = TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_TURRET ).Height - m_gunCenter.y;

	//set the last time we shot
	m_lastShot = clock() - 1400;
}

StationaryTurret::~StationaryTurret() {
}

void StationaryTurret::setPosition( double x, double y ) {
	m_position.x = x;
	m_position.y = y;

	//recalculate the gun position based on the new position
	m_gunPosition.x = ( m_position.x + m_baseCenter.x ) - m_gunCenter.x;
	m_gunPosition.y = ( m_position.y + m_baseCenter.y ) - m_gunCenter.y;
}

void StationaryTurret::tick() {
	//do the collision check
	if( collided ) {
		GAMEENGINE.removeActor(this);
		return;
	}

	//set our new position based on the old position and the change in Y
	setPosition( m_position.x, m_position.y + m_dy );

	//Get the turret location for use in the bullet shoot
	D3DXVECTOR2 m_turretLoc;
	m_turretLoc.x = m_gunPosition.x + m_gunCenter.x;
	m_turretLoc.y = m_gunPosition.y + m_gunCenter.y;

	//Used for tank location calculation
	D3DXVECTOR2 m_tankLoc;

	//we only want to do this if the tank exists. So do a sanity check
	if( GAMEENGINE.getTank() ) {
		//calculate the center of the tank
		m_tankLoc.x = GAMEENGINE.getTank()->getPosition().x + (GAMEENGINE.getTank()->getWidth()/2);
		m_tankLoc.y = GAMEENGINE.getTank()->getPosition().y + (GAMEENGINE.getTank()->getWidth()/2);

		//rotate our turret based on a line to the center of the tank to the center of us
		if( m_turretLoc.y - m_tankLoc.y != 0 ) {
			m_gunRotation = D3DXToDegree( atan( (m_turretLoc.x - m_tankLoc.x) / (m_tankLoc.y - m_turretLoc.y) ) );

			if( m_turretLoc.x <= m_tankLoc.x && m_turretLoc.y < m_tankLoc.y ) {
				//quadrant 1
				m_gunRotation = 360 + m_gunRotation;
			} else if( m_turretLoc.x >= m_tankLoc.x && m_turretLoc.y > m_tankLoc.y )  {
				//quadrant 3
				m_gunRotation = 180 + m_gunRotation;
			} else if( m_turretLoc.x <= m_tankLoc.x && m_turretLoc.y > m_tankLoc.y )  {
				//quadrant 4
				m_gunRotation = 180 + m_gunRotation;
			}
		}
	}

	//if it is time for us to shoot
	if( clock() >= (m_lastShot + 1500) ) {
		m_lastShot = clock();
		//get the tip of the turret
		int turretTipX = m_gunPosition.x + m_gunCenter.x - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Width/2;
		int turretTipY = m_gunPosition.y + m_gunCenter.y - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Height/2;
		
		//get the x and y modifier for the turret
		int turretXModifier = m_gunLength * sin( D3DXToRadian( m_gunRotation + 180 ));
		int turretYModifier = m_gunLength * cos( D3DXToRadian( m_gunRotation + 180 ));

		//add the bullet we fired
		GAMEENGINE.addActor( new EnemyBullet( turretTipX + turretXModifier,
										 turretTipY - turretYModifier, 
										m_gunRotation + 180,
										1) );
	}

	//if we're off screen destroy ourselves
	if( m_position.y > GAME_HEIGHT ) {
		GAMEENGINE.removeActor( this );
		GAMEENGINE.updateScore( -50 ); //dock points
		return;
	}

	//register ourselves as collidable
	GAMEENGINE.registerCollidable(this);
}

void StationaryTurret::draw() {
	
	//draw our base
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_TURRET1_BASE ),
					NULL, NULL, &m_position );

	//draw turret on base
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_TURRET1_TURRET ),
		NULL, &m_gunCenter, &m_gunPosition, 0, m_gunRotation );
}



int StationaryTurret::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width;
}

int StationaryTurret::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Height;
}
