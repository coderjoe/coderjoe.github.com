#ifndef _BULLET_H_
#define _BULLET_H_

#include "Collidable.h"
#include "TextureManager.h"
#include "GFXManager.h"
#include "FontManager.h"
#include "GameEngine.h"
#include <string>

// Bullet trail length
#define T_LEN 4

class Bullet : public Collidable {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	// Create a ullet at location, with direction, speed, and damage
	Bullet( float x = 10, float y = 10, float rot  = 0, int damage_mult = 1, object_t align = fr_bullet);
	~Bullet( void );

	// Location stuff
	double getX();
	double getY();
	double getRotation();
	void setPosition( float x, float y );
	void setRotation( float rot );

	virtual void setCollided( Collidable * other );

	// See Actor.h
	virtual void tick( void );
	virtual void draw( void );
	int getWidth();
	int getHeight();

	// How much damage do we do?
	int getDamage();

protected:
	// Texture, different types of bullet look differnt
	int				m_texture;

	// Stuff for movement and trail drawing
	int				m_speed;
	int				m_damage;
	int				m_odometer;

	D3DXVECTOR2		m_center;

private:
	// Movement values
	float			m_dx;
	float			m_dy;
	float			m_rot;
};

#endif;