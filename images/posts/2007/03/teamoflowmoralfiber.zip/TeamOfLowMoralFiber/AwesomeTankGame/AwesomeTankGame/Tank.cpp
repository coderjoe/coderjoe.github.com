#include "stdafx.h"
#include "Tank.h"
#include "Bullet.h"
#include "GFXManager.h"
#include "GameEngine.h"
#include "D3DManager.h"
#include "InputManager.h"
#include "SoundManager.h"
#include "Powerup.h"
#include "Laser.h"
#include "TankExplosion.h"
#include <sstream>

Tank::Tank(void)
{
	m_position.x = 0.0;
	m_position.y = 0.0;

	//coordinates from bitmap file
	points.push_back(D3DXVECTOR2( 7,48 ));
	points.push_back(D3DXVECTOR2( 26, 13 ));
	points.push_back(D3DXVECTOR2( 74, 12 ));
	points.push_back(D3DXVECTOR2( 89, 48 ));
	points.push_back(D3DXVECTOR2( 89, 90 ));
	points.push_back(D3DXVECTOR2( 7, 90 ));

	dx = 2.0; // side-side speed
	dy = 2.0; // vertical speed
	m_lastBulletAt = clock();
	turretRotation = 0;

	type = friendly;
	obj_type = tank;

	m_trifire = false;
	m_laser = false;
	m_speed_mult = 1.0;
	m_damage_mult = 1;

	m_tankCenter.x = (float)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Width/2;
    m_tankCenter.y = (float)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Height/2;

	m_turretCenter.x = 51; 
	m_turretCenter.y = 63;
	m_turretLength = 62;

	m_soundLoop = SOUNDMANAGER.Play( "sounds/tankengineloop.wav", true, .6 );
}

Tank::~Tank(void)
{
}

void Tank::setPosition( double x, double y ) {
	m_position.x = x;
	m_position.y = y;
}

void Tank::tick(){
	// Check status of powerups
	if( m_power_ticks_remain > 0 ){
		m_power_ticks_remain--;
		if( m_power_ticks_remain == 0 ){
			m_speed_mult = 1.0;
			m_trifire = false;
			m_laser = false;
			m_damage_mult = 1;
			GAMEENGINE.setPowerup( none );
		}
	}

	// Rotate the turret
	int mouseX;
	int mouseY;
	float turretX = m_position.x + m_turretCenter.x;
	float turretY = m_position.y + m_turretCenter.y;
	INPUTMANAGER.MouseCurrentPosition( mouseX, mouseY );

	if( turretY - mouseY != 0 ) {
		turretRotation = D3DXToDegree( atan( (mouseX - turretX) / (turretY - mouseY) ) );
	}

	if( mouseX <= turretX && mouseY < turretY ) {
		//quadrant 1
		turretRotation = 360 + turretRotation;
	} else if( mouseX >= turretX && mouseY < turretY )  {
		//quadrant 2
		//do nothing
	} else if( mouseX >= turretX && mouseY > turretY )  {
		//quadrant 3
		turretRotation = 180 + turretRotation;
	} else if( mouseX <= turretX && mouseY > turretY )  {
		//quadrant 4
		turretRotation = 180 + turretRotation;
	}

	// If we hit omething, make an explosion and remove
	if( collided ) {
		TankExplosion * e = new TankExplosion();
		e->setPosition( m_position.x-20, m_position.y-50 );
		m_soundLoop->stop();
		SOUNDMANAGER.Play( "sounds/object_explode5.wav", false, .6 );
		GAMEENGINE.addActor( e );
		GAMEENGINE.removeActor(this);
		return;
	}

	// Check for bullet firing
	bool bulletFire = INPUTMANAGER.MouseIsLeftDown() || INPUTMANAGER.IsKeyDown(DIK_SPACE);

	if( bulletFire ) {
		fireBullet();
	}

	// Run movement
	bool shift = INPUTMANAGER.IsKeyDown( DIK_LSHIFT );
	bool up = INPUTMANAGER.IsKeyDown( DIK_W );
	bool down = INPUTMANAGER.IsKeyDown( DIK_S );
	bool left = INPUTMANAGER.IsKeyDown( DIK_A );
	bool right = INPUTMANAGER.IsKeyDown( DIK_D );

	if( up ) {
		m_position.y = m_position.y - (dy * m_speed_mult);
	} else if( down ) {
		m_position.y = m_position.y + (dy * m_speed_mult);
	}

	if( left ) {
		m_position.x = m_position.x - (dx * m_speed_mult);
	} else if( right ) {
		m_position.x = m_position.x + (dx * m_speed_mult);
	}

	
	if( m_position.y < 0 ) {
		m_position.y = 0;
	}

	if( m_position.y > (GAME_HEIGHT - (int)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Height ) ) {
		m_position.y = GAME_HEIGHT - (int)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Height;
	}

	if( m_position.x < 0 ) {
		m_position.x = 0;
	}

	if( m_position.x > (GAME_WIDTH - (int)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Width ) ) {
		m_position.x = GAME_WIDTH - (int)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Width;
	}
	
	// Add us to list of objects that hit things
	GAMEENGINE.registerCollidable(this);
}

void Tank::draw(){
	// Draw base
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_TANK ) , 
		NULL,
		&m_tankCenter,
		&m_position,
		NULL,
		0, 
		D3DCOLOR_RGBA(255,255,255,255));

	RECT turretSrc;
	turretSrc.top = turretSrc.left = 0;
	turretSrc.bottom = turretSrc.right = 100;

	// Draw turret
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_TANK_TURRET ),
		&turretSrc,
		&m_turretCenter,
		&m_position,
		NULL,
		turretRotation
		);
}

void Tank::fireBullet(bool force){
	clock_t currentTime = clock();
	// Check delay before firing, different for bullet and laser
		if( (!m_laser && currentTime - m_lastBulletAt > 100) || force || (m_laser && currentTime - m_lastBulletAt > 500) ) {
			m_lastBulletAt = clock();
			// Find rotation to shoot
			int turretTipX = m_position.x + m_turretCenter.x - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Width/2;
			int turretTipY = m_position.y + m_turretCenter.y - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Height/2;
			int turretXModifier = m_turretLength * sin( D3DXToRadian( turretRotation ));
			int turretYModifier = m_turretLength * cos( D3DXToRadian( turretRotation ));

			if( m_laser){
				GAMEENGINE.addActor( new Laser( turretTipX + turretXModifier,
												 turretTipY - turretYModifier, 
												turretRotation ) );
				SOUNDMANAGER.Play("sounds/laser_fire1.wav", false, .8);
			} else {
				GAMEENGINE.addActor( new Bullet( turretTipX + turretXModifier,
												 turretTipY - turretYModifier, 
												turretRotation,
												m_damage_mult) );
				// Extra bullets in trifire mode (10 degree spread)
				if( m_trifire ){
					GAMEENGINE.addActor( new Bullet( turretTipX + turretXModifier,
												 turretTipY - turretYModifier, 
												fmod(turretRotation+10, 360),
												m_damage_mult) );
					GAMEENGINE.addActor( new Bullet( turretTipX + turretXModifier,
												 turretTipY - turretYModifier, 
												 (turretRotation-10<0)?turretRotation+345:turretRotation-10,
												m_damage_mult) );
				}
				SOUNDMANAGER.Play("sounds/cannon_fire1.wav", false, .6);			
			}
		}
}

int Tank::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Width;
}

int Tank::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Height;
}

void Tank::setCollided( Collidable* other ){
	object_t otype = other->getObjectType();
	// dead if hit bullets or enemies
	if( otype == fo_bullet || otype == ground_enemy || otype == air_enemy){
		collided = true;
	}
	// Powerup handling
	if( otype == powerup ){
		m_speed_mult = 1.0;
		m_trifire = false;
		m_damage_mult = 1;
		m_laser = false;

		Powerup* pow = dynamic_cast<Powerup*>(other);
		GAMEENGINE.setPowerup( pow->getPowType() );
		m_power_ticks_remain = POWERUP_DURATION;
		switch( pow->getPowType() ){
			case fire:
				m_damage_mult = 3;
				break;
			case speed:
				m_speed_mult = 2.0;
				break;
			case tri:
				m_trifire = true;
				break;
			case laser:
				m_power_ticks_remain = POWERUP_DURATION/2;
				m_lastBulletAt-= 500;
				m_laser = true;
				break;
		}
	}
}