/*
 * Horizontal tank defines a horizontally moving tank which bounces off screen bounderies
 * intially moving right
 */
#ifndef _HORIZONTALTANK_H_
#define _HORIZONTALTANK_H_

#include "Enemy.h"
#include <time.h>

class HorizontalTank : public Enemy {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	//Constructor and destructor
	HorizontalTank();
	~HorizontalTank();

	//Set position overrid from collidable
	void setPosition( double x, double y );

	//set the direction of this tank
	void setDirection( int d );

	//get width and height override from actor
	int getWidth();
	int getHeight();

	//tick and draw override from actor
	void tick();
	void draw();
private:
	int m_dx; //x direction modifier
	int m_dy; //y direction modifier
	int rotate; //rotation

	clock_t		m_lastShot; //the last time this tank shot
};

#endif