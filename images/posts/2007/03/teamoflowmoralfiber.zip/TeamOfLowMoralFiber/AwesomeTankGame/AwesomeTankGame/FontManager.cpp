#include "FontManager.h"

#include <iostream>
#include <sstream>

FontManager::FontManager() {
	// font map info
	m_charsPerRow = 15;
	m_charsPerCol = 7;
	m_indexStartPos = static_cast<int>('!');
}

FontManager::~FontManager() {
}

void FontManager::asciiToIndex( char c, int & x, int & y ) {
	// translate letter to index into map
	int index = static_cast<int>(c) - m_indexStartPos;

	x = index % m_charsPerRow;
	y = ((int)index / m_charsPerRow);
}

void FontManager::draw( int texture, std::string text, float x, float y, D3DCOLOR color, float width, float height ) {
	LPDIRECT3DTEXTURE9		fontTexture = TEXTUREMANAGER.getTexture( texture );
	D3DXIMAGE_INFO			imageInfo = TEXTUREMANAGER.getTextureInfo( texture );

	// We know that our font textures are m_charsPerRow characters wide 
	// and m_charsPerCol characters high so lets grab each character size

	int characterWidth = imageInfo.Width / m_charsPerRow;
	int characterHeight = imageInfo.Height / m_charsPerCol;
	int texX;
	int texY;

	//Stuff we use for the draw command
	RECT srcRect;
	D3DXVECTOR2 center;
	center.x = 0;
	center.y = 0;
	
	//Set up our starting position
	D3DXVECTOR2 position;
	position.x = x;
	position.y = y;

	D3DXVECTOR2 scaling;
	scaling.x = scaling.y = 1;
	
	if( width > 0 ) {
		scaling.x = (float)width;
		width = characterWidth * scaling.x;
	} else {
		width = characterWidth;
	}

	if( height > 0 ) {
		scaling.y = (float)height;
		height = characterHeight * scaling.y;
	} else {
		height = characterHeight;
	}

	for( unsigned int i = 0; i < text.length(); i++ ) {
		switch( text.at(i) ) {
			case ' ':
				position.x += width;
				break;
			case '\n':
				position.x = x;
				position.y += height;
				break;
			default:
				asciiToIndex( text.at( i ), texX, texY );
				//turn the index coordinates into coordinates on the image itself.
				texX = texX * characterWidth;
				texY = texY * characterHeight;

				srcRect.top = texY;
				srcRect.left = texX;
				srcRect.bottom = texY + characterHeight;
				srcRect.right = texX + characterWidth;

				GFXMANAGER.draw( TEXTUREMANAGER.getTexture(texture) , &srcRect, &center, &position, &scaling, 0, color );

				position.x += width;
				break;
		};
	}
}
