/*
 * Horizontal Tank Left defines a tank which moves horizontally bouncing off the screen
 * bounderies initially moving left
 */
#ifndef _HORIZONTALTANKLEFT_H_
#define _HORIZONTALTANKLEFT_H_

#include "Enemy.h"
#include <time.h>

class HorizontalTankLeft : public Enemy {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	// Constructor and destructor
	HorizontalTankLeft();
	~HorizontalTankLeft();

	//Set position override from Collidable
	void setPosition( double x, double y );
	
	//set the direction of the tank
	void setDirection( int d );

	//Get width and height override from Collidable
	int getWidth();
	int getHeight();

	//tick and draw override from actor
	void tick();
	void draw();
private:
	int m_dx; //change in X modifier
	int m_dy; //change in Y modifier
	int rotate; //current rotation

	clock_t		m_lastShot; // the last timethis tank shot
};

#endif