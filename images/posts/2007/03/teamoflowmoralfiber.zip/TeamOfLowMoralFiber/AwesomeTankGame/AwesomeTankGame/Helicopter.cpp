#include "stdafx.h"
#include "Helicopter.h"
#include "D3DManager.h"
#include "SoundManager.h"
#include "GameEngine.h"
#include "Explosion.h"
#include "PowerUpFactory.h"

const std::string Helicopter::IDENTIFIER = "HELICOPTER";

Helicopter::Helicopter() {
	type = foe; //enemy
	obj_type = air_enemy; //in the air
	m_dx = 3;
	m_dy = 2;
	rotate = 0;
	m_score = 150;

	//set collision parameters
	points.push_back(D3DXVECTOR2(50,0));
	points.push_back(D3DXVECTOR2(70,50));
	points.push_back(D3DXVECTOR2(50,83));
	points.push_back(D3DXVECTOR2(25,50));
}

Helicopter::~Helicopter() {
}

void Helicopter::setPosition( double x, double y ) {
	m_position.x = x;
	m_position.y = y;
}

void Helicopter::setDirection( int d ) {
	m_dx = d;
}

void Helicopter::tick() {
	//if we collided, unregister us
	if( collided ) {
		GAMEENGINE.removeActor(this);
		return;
	}

	m_position.x = m_position.x + m_dx;
	m_position.y = m_position.y + m_dy;

	rotate = (rotate + 1) % 4;

	//bounce if you have to
	if( m_position.x >= GAME_WIDTH - TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width ||
		m_position.x <= 0 ) {
		m_dx = m_dx * -1;
	}

	//If we are below the scren remove us
	if( m_position.y > GAME_HEIGHT ) {
		GAMEENGINE.removeActor( this );
		GAMEENGINE.updateScore( -75 ); //dock points
		return;
	}

	//register us as collidable
	GAMEENGINE.registerCollidable(this);
}

void Helicopter::draw() {
	//spin through our frames
	if( rotate == 4 )
	{
		rotate = 0;
	}

	if( rotate == 0 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER1 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 1 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER2 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 2 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER3 ),
					NULL, NULL, &m_position );
	}
	else
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER4 ),
					NULL, NULL, &m_position );
	}

	rotate++;

}

int Helicopter::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width;
}

int Helicopter::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Height;
}