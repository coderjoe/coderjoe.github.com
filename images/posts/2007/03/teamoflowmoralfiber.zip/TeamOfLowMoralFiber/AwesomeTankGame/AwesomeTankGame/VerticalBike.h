/*
 * Vertical bike defines the verticle bike enemy
 * Enemy drives straight down to bottom with no left right movemetn
 */
#ifndef _VERTICALBIKE_H_
#define _VERTICALBIKE_H_

#include "Enemy.h"

class VerticalBike : public Enemy {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	/*
	 * Constructors and destructors
	 */
	VerticalBike();
	~VerticalBike();

	//Set position override from actor
	//sets the position of the object
	void setPosition( double x, double y );
	//Set direction override
	void setDirection( int d );

	//Get width and height override from Actor
	int getWidth();
	int getHeight();

	//Tick override from actor
	void tick();
	//Draw override from actor
	void draw();
private:
	int m_dx; //deviation in x per tick
	int m_dy; //deviation in y per tick
	int rotate; //current rotation
};

#endif