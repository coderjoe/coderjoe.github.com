/*
 * AnimTest is a test animation class
 * Please do not use this in production code
 *
 */

#pragma once
#include "Collidable.h"
#include "TextureManager.h"

class AnimTest :
	public Collidable
{
public:
	AnimTest(void);
	~AnimTest(void);
	void draw();
	void tick();
private:
	static const int texture = TEX_TEST_ANIM;
	float alpha;
};
