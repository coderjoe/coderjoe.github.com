#include "GFXManager.h"
#include "D3DManager.h"


GFXManager::GFXManager(void){
	initSprite();
}

GFXManager::~GFXManager(void){
	killSprite();
}


void GFXManager::initSprite() {
	D3DXCreateSprite( D3DMANAGER.getDevice(), &m_sprite );
}

void GFXManager::killSprite() {
	if( m_sprite ) {
		m_sprite->Release();
		m_sprite = NULL;
	}
}

// begin scene
void GFXManager::begin() {
	m_sprite->Begin( D3DXSPRITE_ALPHABLEND  );
}

// end scene
void GFXManager::end() {
	m_sprite->End();
}

void GFXManager::draw( LPDIRECT3DTEXTURE9 pTexture, 
				CONST RECT *pSrcRect,
				CONST D3DXVECTOR2 *center,
				CONST D3DXVECTOR2 *pPosition,
				CONST D3DXVECTOR2 *pScaling,
				UINT rotation,
				D3DCOLOR Color){

	// calculate scaling and rotation
	D3DXMATRIX result;
	D3DXMatrixTransformation2D( &result, center, 0, pScaling, center, D3DXToRadian(rotation), pPosition ); 

	m_sprite->SetTransform( &result );
	m_sprite->Draw( pTexture , 
			pSrcRect, 
			NULL, 
			NULL, 
			Color);
}