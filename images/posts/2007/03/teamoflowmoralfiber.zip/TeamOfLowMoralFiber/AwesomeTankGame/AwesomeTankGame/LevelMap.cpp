#include "stdafx.h"
#include "LevelMap.h"
#include <iostream>
#include <fstream>

LevelMap::LevelMap( std::string filename ) {
	std::ifstream mapfile; //map file input
	mapfile.open( filename.c_str() ); //open the file

	std::string keyword;
	
	//for map calculation
	int r = 0;
	int c = 0;
	int numcols = 0;
	int numrows = 0;

	//for baddies
	int numbaddies = 0;
	std::string baddiename;
	int baddyX;
	int baddyY;

	//grab speed
	mapfile >> keyword;
	if( keyword == "SPEED" ) {
		mapfile >> m_iSpeed;
	}

	//grab drawfrom
	mapfile >> keyword;
	if( keyword == "DRAWFROM" ) {
		mapfile >> m_iDrawXStart;
		mapfile >> m_iDrawYStart;
	}

	//load map specifics
	mapfile >> keyword;
	if( keyword == "MAP" ) {
		mapfile >> numrows;
		mapfile >> numcols;

		int temp = 0;

		mapfile >> temp;
		while( !mapfile.eof() ) {
			if( c == 0 ) {
				m_vvMap.push_back( TextureVector() );
			}

			m_vvMap[r].push_back( temp );
			
			c++;

			if( ( c % numcols ) == 0 ) {
				r++;
				c=0;
			}
			mapfile >> temp;
		}

		//set defaults
		m_iOffset = 0;
		m_iStartIndex = 0;
		m_iDrawYStart = D3DMANAGER.getHeight() - TILE_OFFSET + m_iDrawYStart;
		m_iRowsPerScreen = numrows;

	}
}

LevelMap::~LevelMap() {
}

void LevelMap::tick() {
	//tick the map by the speed
	m_iOffset += m_iSpeed;

	//do the calculation to pop the next row based on offset
	if( ( (int)m_iOffset % TILE_HEIGHT ) == 0 ) {
		m_iStartIndex = ( m_iStartIndex + 1 ) % m_vvMap.size();
		m_iOffset = 0;
	}
}

void LevelMap::draw() {
	//draw the tiles for this screen group
	static int callNum = 0;
	callNum++;
	D3DXVECTOR2 position;
	position.x = m_iDrawXStart; //calculate X position
	position.y = m_iDrawYStart + m_iOffset; //calculate y based on start and offset(this advances the screen)

	int row = m_vvMap.size() - ( m_iStartIndex + 1 );

	//spin through rows
	for( int r = 0; r < m_iRowsPerScreen; r++ ) {
		position.x = m_iDrawXStart;
		//for( int col = m_vvMap[row].size() - 1; col >= 0 ; col-- ) {
		//spin through the columns
		for( unsigned int col = 0; col < m_vvMap[row].size(); col++ ) {
			//get the map texture
			if( m_vvMap[row][col] >= 0 ) {
				GFXMANAGER.draw( TEXTUREMANAGER.getTexture( m_vvMap[row][col] ), 
							NULL, NULL, &position );
			}
			position.x += TILE_WIDTH;
		}

		//go to the next row
		row = row--;
		if( row < 0 ) {
			row = m_vvMap.size() - 1; 
		}

		//subtract through tile height to go to the next row
		position.y -= TILE_HEIGHT;
	}
}

int LevelMap::getSpeed() {
	//access speed
	return m_iSpeed;
}