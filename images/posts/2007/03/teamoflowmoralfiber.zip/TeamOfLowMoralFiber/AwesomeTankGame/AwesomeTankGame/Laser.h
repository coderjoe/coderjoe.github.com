#pragma once
#include "Collidable.h"

class Laser :
	public Collidable
{
public:
	// Create a laser beam with start position and direction
	Laser(float x = 10, float y = 10, float rot  = 0);
	~Laser(void);

	void setCollided( Collidable * other );

	// See Actor.h
	void draw();
	void tick();
	int getWidth();
	int getHeight();


private:
	float			m_dx;
	float			m_dy;

	// For drawing
	float			m_fade;

	D3DXVECTOR2		m_center;
	float			m_rot;
};
