#include "stdafx.h"
#include "Movement.h"

// Moves an object based on the object's set movement speed
Movement::Movement( Collidable * obj, double speed )
: m_obj( obj ), m_speed( speed ) {
}

Movement::~Movement() {
}