#ifndef _MOVEMENT_H_
#define _MOVEMENT_H_

#include "Collidable.h"

class Movement {
public:
	Movement( Collidable * obj , double speed );
	virtual ~Movement();

	// initMove() will initialize the move
	virtual void initMove() {};
	// does the move
	virtual void move() {};
protected:
	// The object to move
	Collidable		*m_obj;
	// The speed to move at.
	double			m_speed;
};

#endif