#ifndef _MAIN_MENU_H_
#define _MAIN_MENU_H_

#include "Actor.h"
#include "d3d9.h"

class MainMenu : public Actor {
public:
	MainMenu();
	virtual ~MainMenu();

	// see Actor.h
	virtual void tick();
	virtual void draw();

	virtual int getHeight();
	virtual int getWidth();
private:
	// Dimensions for buttons
	int m_menuYMin;
	int m_menuYMax;
	int	m_startGameXMin;
	int m_startGameXMax;
	int m_quitGameXMin;
	int m_quitGameXMax;

	D3DCOLOR	m_buttonColor;
	D3DCOLOR	m_hoverColor;
};

#endif