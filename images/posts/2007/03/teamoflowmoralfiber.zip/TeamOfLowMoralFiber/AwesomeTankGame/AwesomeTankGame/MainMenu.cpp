#include "stdafx.h"
#include "MainMenu.h"
#include "GameEngine.h"
#include "FontManager.h"

MainMenu::MainMenu() {
	m_menuYMin = 667;
	m_menuYMax = m_menuYMin + 44;

	m_startGameXMin = 62;
	m_startGameXMax = m_startGameXMin+286;

	m_quitGameXMin = 801;
	m_quitGameXMax = m_quitGameXMin + 108;

	m_buttonColor = D3DCOLOR_XRGB(255,255,0);
	m_hoverColor = D3DCOLOR_XRGB(255,0,0);

}

MainMenu::~MainMenu() {
}

// no animations
void MainMenu::tick() {
}

void MainMenu::draw() {
	D3DCOLOR startColor = m_buttonColor;
	D3DCOLOR quitColor = m_buttonColor;
	int mouseX;
	int mouseY;

	INPUTMANAGER.MouseCurrentPosition( mouseX, mouseY );
	bool mouseDown = INPUTMANAGER.MouseIsLeftDown();

	if( m_menuYMin <= mouseY && mouseY <= m_menuYMax ) {
		if( m_startGameXMin <= mouseX && mouseX <= m_startGameXMax ) {
			startColor = m_hoverColor;

			if(mouseDown) {
				GAMEENGINE.startGame();
			}
		} else if( m_quitGameXMin <= mouseX && mouseX <= m_quitGameXMax ) {
			quitColor = m_hoverColor;
			if(mouseDown) {
				GAMEENGINE.quitGame();
			}
		}
	}

	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_SCREEN_MAIN_MENU ) );

	FONTMANAGER.draw( TEX_FONT_FUTURA, "Start Game", m_startGameXMin+5, m_menuYMin+5, D3DCOLOR_ARGB( 170, 0, 0, 0 ),1.5,1.5);
	FONTMANAGER.draw( TEX_FONT_FUTURA, "Start Game", m_startGameXMin, m_menuYMin, startColor,1.5,1.5);

	FONTMANAGER.draw( TEX_FONT_FUTURA, "Quit", m_quitGameXMin+5, m_menuYMin+5, D3DCOLOR_ARGB( 170, 0, 0, 0 ),1.5,1.5);
	FONTMANAGER.draw( TEX_FONT_FUTURA, "Quit", m_quitGameXMin, m_menuYMin, quitColor,1.5,1.5);
}

int MainMenu::getWidth() {
	return GAME_WIDTH;
}

int MainMenu::getHeight() {
	return GAME_HEIGHT;
}