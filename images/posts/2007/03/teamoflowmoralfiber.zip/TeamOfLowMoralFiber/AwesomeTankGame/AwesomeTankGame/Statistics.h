#ifndef _STATISTICS_H_
#define _STATISTICS_H_
/*
 * Statistics.h
 */

#include <windows.h>
#include <time.h>
#include <d3dx9.h>
#include "Singleton.h"

#define STATISTICS Statistics::Instance()

// Holds, and calculates various statistics, including the frames per second
class Statistics : public Singleton<Statistics> {
	friend class Singleton<Statistics>;
protected:
	Statistics();
	~Statistics();
public:
	// Calculates the frame rate
	void calculateFrameRate();

	// Gets the set frame rate
	int getFrameRate();
private:
	// Variables involving the statistics
	clock_t	m_currentClock;
	clock_t m_checkClock;
	double	m_frameCount;
	double	m_framesPerSecond;

	int		m_interval;
};

#endif