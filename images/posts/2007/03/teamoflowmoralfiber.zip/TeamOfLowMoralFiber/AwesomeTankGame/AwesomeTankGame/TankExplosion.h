#ifndef _TANK_EXPLOSION_H_
#define _TANK_EXPLOSION_H_

#include "Explosion.h"
#include "d3dx9.h"

class TankExplosion : public Explosion {
public:
	TankExplosion();
	virtual ~TankExplosion();

	// See Actor.h for the below
	virtual void draw();
	virtual int getWidth();
	virtual int getHeight();

	//End the animation, remove the explosion
	virtual void endExplosion();
private:
	// Explosion size
	D3DXVECTOR2		m_scaling;
};

#endif