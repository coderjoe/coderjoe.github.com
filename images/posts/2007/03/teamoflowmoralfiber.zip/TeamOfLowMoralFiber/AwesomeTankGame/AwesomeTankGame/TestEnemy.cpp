#include "stdafx.h"
#include "TestEnemy.h"
#include "D3DManager.h"
#include "SoundManager.h"
#include "GameEngine.h"
#include "Explosion.h"
#include "PowerUpFactory.h"
#include "MoveAroundPoint.h"

const std::string TestEnemy::IDENTIFIER = "TEST_ENEMY";

TestEnemy::TestEnemy() {
	type = foe; //we are an enemy
	obj_type = air_enemy; //we fly
	m_dx = 3;
	m_dy = 2;
	rotate = 0;

	//Set up collision detection 
	points.push_back(D3DXVECTOR2(50,0));
	points.push_back(D3DXVECTOR2(70,50));
	points.push_back(D3DXVECTOR2(50,83));
	points.push_back(D3DXVECTOR2(25,50));

	//set up the test movement
	m_move = new MoveAroundPoint( this, 1, D3DXVECTOR2( 50, 50) );
	m_move->initMove();
}

TestEnemy::~TestEnemy() {
}

void TestEnemy::setPosition( double x, double y ) {
	static int direction = -1;
	if( direction == -1 ) {
		direction = 1;
	} else if( direction == 1 ) {
		direction = -1;
	}
	m_position.x = x;
	m_position.y = y;

	//destroy our move if it exists, we need to make a new one
	if( m_move ) {
		delete m_move;
		m_move = NULL;
	}

	//update the movement based around the new position
	m_move = new MoveAroundPoint( this, 1, D3DXVECTOR2( 50, 50 ), direction );
	m_move->initMove();
}

void TestEnemy::setDirection( int d ) {
	m_dx = d;
}

void TestEnemy::tick() {
	//calculate the move
	m_move->move();
	//modify the rotation
	rotate = (rotate + 1) % 4;

	//set ourselves collidable
	GAMEENGINE.registerCollidable(this);
}

void TestEnemy::draw() {
	//spin through the frames
	if( rotate == 4 )
	{
		rotate = 0;
	}

	if( rotate == 0 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER1 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 1 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER2 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 2 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER3 ),
					NULL, NULL, &m_position );
	}
	else
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER4 ),
					NULL, NULL, &m_position );
	}

	//do collision check
	if( collided ) {
		//play boom
		SOUNDMANAGER.Play( "sounds/object_explode5.wav", false, .6 );
		
		//make an explosion
		Explosion * explsn = new Explosion();
		explsn->setPosition( m_position.x, m_position.y );
		PowerUpFactory::CreatePowerUpAt(m_position.x, m_position.y);

		//remove ourselves
		GAMEENGINE.removeActor(this);
		
		//add the explosion
		GAMEENGINE.addActor( explsn );
		GAMEENGINE.updateScore( 50 ); //add points
		
		return;
	}
}

int TestEnemy::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width;
}

int TestEnemy::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Height;
}