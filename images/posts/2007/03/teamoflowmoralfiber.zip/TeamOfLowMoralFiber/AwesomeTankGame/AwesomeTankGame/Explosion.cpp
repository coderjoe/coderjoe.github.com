#include "stdafx.h"
#include "Explosion.h"
#include "D3DManager.h"
#include "SoundManager.h"
#include "GameEngine.h"

const std::string Explosion::IDENTIFIER = "EXPLOSION";

Explosion::Explosion() {
	type = neutral;
	m_texture = TEX_EXPLOSION1;

	m_frameNum = 0;

	m_textureWidth = 71;
	m_textureHeight = 100;

	m_frameCount = 17;

	m_frameRect.top = 0;
	m_frameRect.left = 0;
	m_frameRect.bottom = m_textureHeight;
	m_frameRect.right = m_textureWidth;

	m_frameSpeed = 30;
	m_prevTime = 0;
}

Explosion::~Explosion() {
}

void Explosion::setPosition( double x, double y ) {
	m_position.x = x;
	m_position.y = y;
}

void Explosion::tick() {
	// Move down screen, iterate through frames of animation
	m_position.y = m_position.y + GAMEENGINE.getLevel()->getSpeed();

	clock_t now = clock();
	if( now >= (m_prevTime + m_frameSpeed) ) {
		m_prevTime = now;
		m_frameNum++;

		m_frameRect.left = m_frameRect.left + m_textureWidth;

		if( m_frameRect.left >= TEXTUREMANAGER.getTextureInfo( m_texture ).Width ) {
			m_frameRect.left = 0;
			m_frameRect.top = m_frameRect.top + m_textureHeight;

			if( m_frameRect.top >= TEXTUREMANAGER.getTextureInfo( m_texture ).Height ) {
				m_frameRect.top = 0;
			}
		}

		m_frameRect.bottom = m_frameRect.top + m_textureHeight;
		m_frameRect.right = m_frameRect.left + m_textureWidth;
	}

	if( m_frameNum >= m_frameCount || m_position.y > D3DMANAGER.getHeight() ) {
		endExplosion();
		return;
	}
}

void Explosion::draw() {

	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( m_texture ),
					&m_frameRect, NULL, &m_position );

}

int Explosion::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( m_texture ).Width;
}

int Explosion::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( m_texture ).Height;
}

void Explosion::endExplosion() {
	GAMEENGINE.removeActor( this );
}
