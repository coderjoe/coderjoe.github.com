/*
 * Stationary turret describes the stationary enemy moving with the map
 * which rotates its turret to shoot at the player
 */

#ifndef _STATIONARYTURRET_H_
#define _STATIONARYTURRET_H_

#include "Enemy.h"
#include <time.h>

class StationaryTurret : public Enemy {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	// Constructor and destructor
	StationaryTurret();
	~StationaryTurret();

	// Set position override fom collidable
	void setPosition( double x, double y );

	// Width and height override from actor
	int getWidth();
	int getHeight();

	// tick and draw override from actor
	void tick();
	void draw();
private:
	int m_dy; //change in Y modifier

	D3DXVECTOR2 m_baseCenter; // the center of the base of the turret
	D3DXVECTOR2 m_gunCenter; //the center of the gun on the turret
	D3DXVECTOR2 m_gunPosition; //the position of the gun
	int m_gunRotation; //the rotation of the gun in degrees
	int m_gunLength; //the length of the gun turret

	clock_t		m_lastShot; //the time of the last shot
};

#endif