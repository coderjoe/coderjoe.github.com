/*
 * The MLHelicopter class overrides the Helicopter to provide MovementList support
 * to the helicopter to make use of the advanced Movement List stuff.
 */
#ifndef _ML_HELICOPTER_H_
#define _ML_HELICOPTER_H_

#include "MovementList.h"
#include "Helicopter.h"

class MLHelicopter : public Helicopter {
public:
	// Cosntructor and destructor
	MLHelicopter();
	virtual ~MLHelicopter();

	// getMovementList()
	// returns: the MovementList reference for this MLHelicopter
	MovementList & getMovementList();

	// The tick overrided from Helicopter
	virtual void tick();

private:
	MovementList	m_moveList; // the stored movement list for this MLHelicopter
};

#endif