#pragma once

#include "Collidable.h"
#include "TextureManager.h"
#include "Powerup.h"
#include "SoundManager.h"
#include "fmod/fmod.hpp"
#include <time.h>

#define POWERUP_DURATION 1200

class Tank :
	public Collidable
{
	friend class Collidable;
public:
	Tank(void);
	~Tank(void);

	// Relocate Tank
	void setPosition( double x, double y );

	//See Actor.h
	void draw(void);
	void tick(void);
	int getWidth();
	int getHeight();

	void setCollided( Collidable* other );

private:
	// Code for firing bullet (more complex than it looks)
	void	fireBullet( bool force = false );

	static const int texture = TEX_TANK;
	
	// Movement values
	double dx;
	double dy;
	double dspeed;
	double turretRotation;
	double rot;
	double drot;

	//Valuable for firing bullets
	D3DXVECTOR2 m_tankCenter;
	D3DXVECTOR2 m_turretCenter;
	int			m_turretLength;

	//Powerup stuff
	int			m_power_ticks_remain;
	bool		m_trifire;
	bool		m_laser;
	float		m_speed_mult;
	int			m_damage_mult;
	Powerup*	m_current_powerup;
	
	//sound loop stuff
	FMOD::Channel * m_soundLoop;

	//bullet stuff
	clock_t m_lastBulletAt;
};
