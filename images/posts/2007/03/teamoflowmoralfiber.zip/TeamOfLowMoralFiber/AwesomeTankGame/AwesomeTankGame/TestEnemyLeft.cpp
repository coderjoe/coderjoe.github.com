#include "stdafx.h"
#include "TestEnemyLeft.h"
#include "D3DManager.h"
#include "SoundManager.h"
#include "GameEngine.h"
#include "Explosion.h"
#include "PowerUpFactory.h"

const std::string TestEnemyLeft::IDENTIFIER = "TESTLEFT_ENEMY";

TestEnemyLeft::TestEnemyLeft() {
	type = foe; //we're an enemy
	obj_type = air_enemy; //we fly
	m_dx = -3;
	m_dy = 2;
	rotate = 0;

	//set up the collission detection
	points.push_back(D3DXVECTOR2(50,0));
	points.push_back(D3DXVECTOR2(70,50));
	points.push_back(D3DXVECTOR2(50,83));
	points.push_back(D3DXVECTOR2(25,50));
}

TestEnemyLeft::~TestEnemyLeft() {
}

void TestEnemyLeft::setPosition( double x, double y ) {
	m_position.x = x;
	m_position.y = y;
}

void TestEnemyLeft::setDirection( int d ) {
	m_dx = d;
}

void TestEnemyLeft::tick() {
	//Change our position based on x and y modification
	m_position.x = m_position.x + m_dx;
	m_position.y = m_position.y + m_dy;

	//increase our rotation
	rotate = (rotate + 1) % 4;

	//Check if we should bounce
	if( m_position.x >= D3DMANAGER.getWidth() - TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width ||
		m_position.x <= 0 ) {
		m_dx = m_dx * -1;
	}

	//if we left screen we need to dock points and destroy
	if( m_position.y > D3DMANAGER.getHeight() ) {
		GAMEENGINE.removeActor( this );
		GAMEENGINE.updateScore( -25 );
		return;
	}

	//register as a collidable enemy
	GAMEENGINE.registerCollidable(this);
}

void TestEnemyLeft::draw() {
	
	// Spin through the frames
	if( rotate == 0 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER1 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 1 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER2 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 2 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER3 ),
					NULL, NULL, &m_position );
	}
	else
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_COPTER4 ),
					NULL, NULL, &m_position );
	}

	// do collision check.
	if( collided ) {
		//play explode sound
		SOUNDMANAGER.Play( "sounds/object_explode5.wav", false, .6 );
		
		//create our boom
		Explosion * explsn = new Explosion();
		explsn->setPosition( m_position.x, m_position.y );

		//make a power up randomly
		PowerUpFactory::CreatePowerUpAt(m_position.x, m_position.y);

		//remove ourselves
		GAMEENGINE.removeActor(this);
		
		//add the explosion
		GAMEENGINE.addActor( explsn );
		GAMEENGINE.updateScore( 50 ); //increase the score

		return;
	}
}

int TestEnemyLeft::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width;
}

int TestEnemyLeft::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Height;
}