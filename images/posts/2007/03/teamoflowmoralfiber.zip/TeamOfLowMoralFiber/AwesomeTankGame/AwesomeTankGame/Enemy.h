#pragma once
#include "Collidable.h"

// Basically a class that holds collision handling for enemies, as they all work the same
class Enemy :
	public Collidable
{
public:
	Enemy(void);
	~Enemy(void);

	// Not going to be overrided, check cpp for details
	virtual void setCollided( Collidable* other );

protected:
	// How much is this enemy worth?
	int m_score;
};
