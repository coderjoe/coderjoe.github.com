#include "stdafx.h"
#include "MLHelicopter.h"
#include "GameEngine.h"
#include "EnemyBullet.h"

MLHelicopter::MLHelicopter() 
: Helicopter() {
	m_lastShot = clock() - 1250; //set the last time we shot
}

MLHelicopter::~MLHelicopter() {
	//m_moveList.~MovementList();
}

MovementList & MLHelicopter::getMovementList() {
	return m_moveList; //return the movment list
}

void MLHelicopter::tick() {
	//if we have collided we need to remove ourselves
	if( collided ) {
		GAMEENGINE.removeActor(this);
		return;
	}

	//if the movement list is done
	if( m_moveList.isDone() ) {
		GAMEENGINE.removeActor(this); //remove ourselves
		GAMEENGINE.updateScore( -75 ); //dock points for not destroying us
		return;
	}

	//change rotation
	rotate = (rotate + 1) % 4;

	//do the movements currently assigned to us
	m_moveList.doMovements();

	//if it's time to shoot
	if( clock() >= (m_lastShot + 1500) ) {
		m_lastShot = clock(); //set the last shot
		
		//get the tip of the turret
		int turretTipX = m_position.x + 50 - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Width/2;
		int turretTipY = m_position.y + 100 - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Height/2;
		
		//spawn our bullet
		GAMEENGINE.addActor( new EnemyBullet( turretTipX,
										 turretTipY, 
										180,
										1) );
	}

	//register ourselves as collidable
	GAMEENGINE.registerCollidable( this );
}