#include "stdafx.h"
#include "YouDiedMenu.h"
#include "GameEngine.h"
#include "FontManager.h"

YouDiedMenu::YouDiedMenu() {
	m_menuYMin = 457;
	m_menuYMax = m_menuYMin + 44;

	m_startGameXMin = 220;
	m_startGameXMax = m_startGameXMin+140;

	m_quitGameXMin = 450;
	m_quitGameXMax = m_quitGameXMin + 108;

	m_buttonColor = D3DCOLOR_XRGB(255,255,0);
	m_hoverColor = D3DCOLOR_XRGB(255,0,0);

	m_displayed = false;
	m_displayedAt = 0;
	m_menuDelay = 1000;
	m_showMenuOptions = false;
}

YouDiedMenu::~YouDiedMenu() {
}

void YouDiedMenu::tick() {
}

void YouDiedMenu::draw() {
	if(!m_displayed) {
		m_displayedAt = clock();
		m_displayed = true;
	} else if( ! m_showMenuOptions && m_displayed && (m_displayedAt + m_menuDelay) <= clock() ) {
		m_showMenuOptions = true;
	}


	D3DCOLOR startColor = m_buttonColor;
	D3DCOLOR quitColor = m_buttonColor;
	int mouseX;
	int mouseY;

	INPUTMANAGER.MouseCurrentPosition( mouseX, mouseY );
	bool mouseDown = INPUTMANAGER.MouseIsLeftDown();

	if( m_showMenuOptions ) {
		if( m_menuYMin <= mouseY && mouseY <= m_menuYMax ) {
			if( m_startGameXMin <= mouseX && mouseX <= m_startGameXMax ) {
				startColor = m_hoverColor;

				if(mouseDown) {
					m_displayed = m_showMenuOptions = false;
					GAMEENGINE.restartGame();
				}
			} else if( m_quitGameXMin <= mouseX && mouseX <= m_quitGameXMax ) {
				quitColor = m_hoverColor;
				if(mouseDown) {
					m_displayed = m_showMenuOptions = false;
					GAMEENGINE.quitGame();
				}
			}
		}
	}

	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_SCREEN_YOU_DIED ) );

	if( m_showMenuOptions ) {
		FONTMANAGER.draw( TEX_FONT_FUTURA, "Retry", m_startGameXMin+5, m_menuYMin+5, D3DCOLOR_ARGB( 170, 0, 0, 0 ),1.5,1.5);
		FONTMANAGER.draw( TEX_FONT_FUTURA, "Retry", m_startGameXMin, m_menuYMin, startColor,1.5,1.5);

		FONTMANAGER.draw( TEX_FONT_FUTURA, "Quit", m_quitGameXMin+5, m_menuYMin+5, D3DCOLOR_ARGB( 170, 0, 0, 0 ),1.5,1.5);
		FONTMANAGER.draw( TEX_FONT_FUTURA, "Quit", m_quitGameXMin, m_menuYMin, quitColor,1.5,1.5);
	}
}

int YouDiedMenu::getWidth() {
	return GAME_WIDTH;
}

int YouDiedMenu::getHeight() {
	return GAME_HEIGHT;
}