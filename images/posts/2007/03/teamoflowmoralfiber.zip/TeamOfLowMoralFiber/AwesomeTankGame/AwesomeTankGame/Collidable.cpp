#include "stdafx.h"
#include "Collidable.h"

Collidable::Collidable(void)
{
	// Some defaults
	collided = false;
	m_position.x = 10;
	m_position.y = 10;
	m_health = 1;
}

Collidable::~Collidable(void)
{
}

std::vector<D3DXVECTOR2> Collidable::getPoints(){
	return points;
}

void Collidable::setPosition( D3DXVECTOR2 nPos ){
	m_position.x = nPos.x;
	m_position.y = nPos.y;
}

D3DXVECTOR2 Collidable::getPosition(){
	return m_position;
}

void Collidable::setCollided( Collidable* other ){
	collided = true;
}

void Collidable::collide( std::vector<Collidable*> others ){
	//only run checks if we have not hit anything yet
	if( !collided ){
		for( int i = 0; i < others.size(); ++i ){  // for every other object...
			std::vector<D3DXVECTOR2> othPoints = others[i]->getPoints();
			for( int myIndex = 0; myIndex < points.size(); myIndex++ ){
				for( int othIndex = 0; othIndex < othPoints.size(); othIndex++ ){
					if( checkIntersection( points[myIndex], points[(myIndex+1)%points.size()],
						othPoints[othIndex], othPoints[(othIndex+1)%othPoints.size()] ,
						m_position, others[i]->m_position) ){
							setCollided(others[i]);
							others[i]->setCollided(this);
							break;
					}
				}
				if( collided )
					break;
			}
		}
	}
}

//  Collision detection code is based on paper by Andy Phelps, including variable names.
bool checkIntersection( D3DXVECTOR2 a, D3DXVECTOR2 b, D3DXVECTOR2 c, D3DXVECTOR2 d,  D3DXVECTOR2 offset1, D3DXVECTOR2 offset2 ){
	//set up line segments
	a.x += offset1.x;
	b.x += offset1.x;
	a.y += offset1.y;
	b.y += offset1.y;
	c.x += offset2.x;
	d.x += offset2.x;
	c.y += offset2.y;
	d.y += offset2.y;
	
	// denominator for both functions
	float den = (b.x - a.x)*(d.y - c.y) - (b.y - a.y) * (d.x - c.x);
	if( fabs(den) < .01 ) // den == 0, parallel
		return false;
	
	// check values of line equations
	float r = (a.y - c.y)*(d.x - c.x) - (a.x - c.x)*(d.y - c.y);
	if( den > 0 ){
		if( r < 0 || r > den )
			return false;
	} else if( r > 0 || r < den ){
		return false;
	}

	float s = (a.y - c.y)*(b.x - a.x) - (a.x - c.x)*(b.y - a.y);
	if( den > 0 ){
		if( s < 0 || s > den )
			return false;
	} else if( s > 0 || s < den ){
		return false;
	}
	return true;
}