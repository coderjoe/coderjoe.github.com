#ifndef _YOU_DIED_MENU_H_
#define _YOU_DIED_MENU_H_

#include "Actor.h"
#include "d3d9.h"
#include <time.h>

class YouDiedMenu : public Actor {
public:
	YouDiedMenu();
	virtual ~YouDiedMenu();

	// See Actor.h
	virtual void tick();
	virtual void draw();
	virtual int getHeight();
	virtual int getWidth();
private:
	// Dimensions for user buttons
	int m_menuYMin;
	int m_menuYMax;
	int	m_startGameXMin;
	int m_startGameXMax;
	int m_quitGameXMin;
	int m_quitGameXMax;

	// display member objects
	bool		m_displayed;
	bool		m_showMenuOptions;
	clock_t		m_displayedAt;
	int			m_menuDelay;

	D3DCOLOR	m_buttonColor;
	D3DCOLOR	m_hoverColor;
};

#endif