/*
 * LevelMap defines the scenery for the level stored in the level file
 * See enemyList.txt for an example file
 */

#ifndef _LEVELMAP_H_
#define _LEVELMAP_H_

#include <vector>
#include <string>

#include "Statistics.h"
#include "GFXManager.h"
#include "D3DManager.h"
#include "TextureManager.h"

// The tile offsets for use in calculating widths and heights
#define TILE_WIDTH  100
#define TILE_HEIGHT 100
#define TILE_OFFSET 50 //should be half the height

//Specific types for easier typing
typedef	std::vector< int >				TextureVector;
typedef std::vector< TextureVector >		MapMatrix;

class LevelMap {
public:
	//constructor
	//argument: filename - the filename to load
	LevelMap( std::string filename );
	~LevelMap();

	//get the speed for this layer
	int getSpeed();

	//tick the map(advance frame)
	void tick();
	//draw the map
	void draw();

private:
	MapMatrix	m_vvMap; //map texture matrix
	double		m_iDrawXStart; //x offset  to draw
	double		m_iDrawYStart; //y offset to draw
	double		m_iOffset; //the offset per tick to smooth scroll
	double		m_iSpeed; //the speed of the map
	int			m_iStartIndex; //the starting index of the map
	int			m_iRowsPerScreen; //number of rows per screen
};

#endif