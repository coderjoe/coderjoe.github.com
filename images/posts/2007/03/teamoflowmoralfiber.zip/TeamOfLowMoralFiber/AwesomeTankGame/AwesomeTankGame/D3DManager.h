#ifndef _D3DManager_H_
#define _D3DManager_H_

#include "GameWindow.h"

#define D3DMANAGER D3DManager::Instance()

// Manage all the D3D stuff we don't ever want to see again
class D3DManager : public Singleton<D3DManager> {
	friend class Singleton<D3DManager>;
protected:
	D3DManager();
	~D3DManager();
public:
	// Video setup
	void setVideoSize( int w, int h );
	void setFormat( D3DFORMAT d3dfmt );

	// Fullscreen settings
	void setFullScreen( bool fullscreen );
	bool getFullScreen();
	void toggleFullScreen();

	// initialization (black magic)
	bool initDevice();
	void releaseDevice();

	// device functions we never ended up using
	LPDIRECT3D9 & getD3D();
	LPDIRECT3DDEVICE9 & getDevice();

	bool isInitialized();

	int getWidth();
	int getHeight();

private:
	HWND					m_hWnd;

	int						m_width;
	int						m_height;
	D3DFORMAT				m_d3dfmt;
	bool					m_fullscreen;

	D3DPRESENT_PARAMETERS	m_d3dpp;
	D3DDISPLAYMODE			m_d3ddm;
	LPDIRECT3D9				m_pd3d;
	LPDIRECT3DDEVICE9		m_pd3ddevice;

	bool m_bInitialized;
};

#endif