#include "stdafx.h"
#include "HorizontalTank.h"
#include "D3DManager.h"
#include "SoundManager.h"
#include "GameEngine.h"
#include "Explosion.h"
#include "PowerUpFactory.h"
#include "EnemyBullet.h"

const std::string HorizontalTank::IDENTIFIER = "HORIZONTAL";

HorizontalTank::HorizontalTank() {
	type = foe; //we're an enemy
	obj_type = ground_enemy; //on the ground
	m_dx = 2;
	m_dy = GAMEENGINE.getLevel()->getSpeed(); //set our speed to the levelspeed
	rotate = 0;
	m_score = 100;

	//set collision parameters
	points.push_back(D3DXVECTOR2(0,0));
	points.push_back(D3DXVECTOR2(120,0));
	points.push_back(D3DXVECTOR2(120,120));
	points.push_back(D3DXVECTOR2(0,120));

	m_lastShot = clock() - 900;
}

HorizontalTank::~HorizontalTank() {
}

void HorizontalTank::setPosition( double x, double y ) {
	m_position.x = x;
	m_position.y = y;
}

void HorizontalTank::setDirection( int d ) {
	m_dx = d;
}

void HorizontalTank::tick() {
	//if we collided, remove us
	if( collided ) {
		GAMEENGINE.removeActor(this);
		return;
	}

	m_position.x = m_position.x + m_dx;
	m_position.y = m_position.y + m_dy;

	//bounce if you need to
	if( m_position.x >= GAME_WIDTH - TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_HORIZ_TANK1 ).Width ||
		m_position.x <= 0 ) {
		m_dx = m_dx * -1;
	}

	//if you need to shoot, shoot
	if( clock() >= (m_lastShot + 1000) ) {
		m_lastShot = clock();
		int turretTipX = m_position.x + 60 - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Width/2;
		int turretTipY = m_position.y + 60 - TEXTUREMANAGER.getTextureInfo( TEX_BULLET_ROUND1 ).Height/2;
		
		int turretXModifier = 0;
		int turretYModifier = -60;

		//spawn the bullet
		GAMEENGINE.addActor( new EnemyBullet( turretTipX + turretXModifier,
										 turretTipY - turretYModifier, 
										180,
										1) );
	}

	//if we're off screen destroy ourselves
	if( m_position.y > GAME_HEIGHT ) {
		GAMEENGINE.removeActor( this );
		GAMEENGINE.updateScore( -50 ); //dock points
		return;
	}

	//register ourselves as collidables
	GAMEENGINE.registerCollidable(this);
}

void HorizontalTank::draw() {
	
	//draw our frames
	if( m_dx < 0 && rotate == 5 )
	{
		rotate = 0;
	}
	if( m_dx > 0 && rotate == -1 )
	{
		rotate = 4;
	}

	if( rotate == 0 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_HORIZ_TANK1 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 1 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_HORIZ_TANK2 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 2 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_HORIZ_TANK3 ),
					NULL, NULL, &m_position );
	}
	else if(rotate == 3 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_HORIZ_TANK4 ),
					NULL, NULL, &m_position );
	}
	else
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_HORIZ_TANK5 ),
					NULL, NULL, &m_position );
	}
	
	if( m_dx < 0 )
	{
		rotate++;
	}
	if( m_dx > 0 )
	{
		rotate--;
	}
}

int HorizontalTank::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_HORIZ_TANK1 ).Width;
}

int HorizontalTank::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_HORIZ_TANK1 ).Height;
}