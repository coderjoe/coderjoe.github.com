#include "stdafx.h"
#include "GameWindow.h"

GameWindow::GameWindow() 
: m_sWinClass( _T("Awesome Tank Game") ), m_hWnd( NULL ), m_hInstance( NULL ),	m_width( 640 ),	m_height( 480 ) {
	m_wc.cbSize = sizeof( WNDCLASSEX );
	m_wc.style = CS_VREDRAW | CS_HREDRAW;
	m_wc.lpfnWndProc = GlobalWinProc;
	m_wc.cbClsExtra = 0;
	m_wc.cbWndExtra = DLGWINDOWEXTRA;
	m_wc.hInstance = m_hInstance;
	m_wc.hIcon = NULL;
	m_wc.hCursor = NULL;
	m_wc.hbrBackground = (HBRUSH) GetStockObject( BLACK_BRUSH );
	m_wc.lpszMenuName = NULL;
	m_wc.lpszClassName = m_sWinClass;
	m_wc.hIconSm = NULL;
}

GameWindow::~GameWindow() {
	UnregisterClass( m_sWinClass, m_hInstance );
}

HINSTANCE & GameWindow::hInstance() {
	return m_hInstance;
}

HWND & GameWindow::hWnd() {
	return m_hWnd;
}

void GameWindow::setDimensions( int w, int h ) {
	m_width = w;
	m_height = h;
}

void GameWindow::setupWindow( HINSTANCE hInst ) {
	m_hInstance = hInst;

	RegisterClassEx( &m_wc );
}

bool GameWindow::createWindow() {
	// Make a new window, with reasonable defaults.
	m_hWnd = CreateWindow(
					m_sWinClass,
					m_sWinClass,
					WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX | WS_VISIBLE,
					0, // x loc
					0, // y loc
					m_width, // window width
					m_height, // window height
					NULL,
					NULL,
					m_hInstance,
					NULL );

	if( ! m_hWnd ) {
		return false;
	}

	ShowWindow( m_hWnd, SW_SHOWDEFAULT );
	UpdateWindow( m_hWnd);

	return true;
}

bool GameWindow::destroyWindow() {
	if( DestroyWindow( m_hWnd ) )
		return true;

	return false;
}

/*
 * GlobalWinProc
 *
 * This function is our global window callback function
 */
LRESULT CALLBACK GlobalWinProc( HWND hWnd,
								UINT uMsg,
								WPARAM wParam,
								LPARAM lParam )
{
	PAINTSTRUCT ps;
	HDC hdc;

	switch( uMsg )
	{
	case WM_CREATE:
		return DefWindowProc( hWnd, uMsg, wParam, lParam );
		break;

	case WM_PAINT:
		hdc = BeginPaint( hWnd, &ps );
		EndPaint( hWnd, &ps );
		break;
	
	case WM_DESTROY:
		PostQuitMessage(0);
		break;
		
	default:
		return DefWindowProc( hWnd, uMsg,wParam,lParam );
	}

	return 0;
}