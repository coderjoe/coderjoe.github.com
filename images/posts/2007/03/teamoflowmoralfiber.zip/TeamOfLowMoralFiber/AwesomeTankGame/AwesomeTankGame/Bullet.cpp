#include "stdafx.h"
#include "Bullet.h"
#include "d3dx9.h"
#include "SinTable.h"


const std::string Bullet::IDENTIFIER = "BULLET";


Bullet::Bullet(float x, float y, float rot, int damage_mult, object_t align) {
	// Basic setup
	m_texture  = TEX_BULLET_ROUND1;
	type = friendly;
	obj_type = align;
	m_speed = 6;
	m_odometer = 0;
	m_damage = 1 * damage_mult;

	setPosition( x, y );
	setRotation( rot );

	m_center.x = static_cast<float> ( TEXTUREMANAGER.getTextureInfo( m_texture ).Width / 2);
	m_center.y = static_cast<float> (TEXTUREMANAGER.getTextureInfo( m_texture ).Height / 2);

	// Hit box
	points.push_back(D3DXVECTOR2(0,0));
	points.push_back(D3DXVECTOR2(10,0));
	points.push_back(D3DXVECTOR2(10,10));
	points.push_back(D3DXVECTOR2(0,10));
}

Bullet::~Bullet() {
}

double Bullet::getX() {
	return m_position.x;
}

double Bullet::getY() {
	return m_position.y;
}

void Bullet::setPosition( float x, float y ) {
	m_position.x = x;
	m_position.y = y;
}

void Bullet::setCollided( Collidable *other ) {
	// Only hit enemies
	if( other->getObjectType() == air_enemy || other->getObjectType() == ground_enemy ) {
		collided = true;
	}
}

int Bullet::getDamage(){
	return m_damage;
}

double Bullet::getRotation() {
	return m_rot;
}

void Bullet::setRotation( float rotation ) {
	m_rot = rotation;

	while( m_rot < 0 ) {
		m_rot += 360.0;
	}

	while( m_rot > 360 ) {
		m_rot -= 360.0;
	}

	m_dy = m_speed * cos( D3DXToRadian(m_rot));
	m_dx = m_speed * sin( D3DXToRadian(m_rot));
}

void Bullet::tick( void ) {
	if( collided ) {
		GAMEENGINE.removeActor(this);
		return;
	}

	m_position.x += m_dx;
	m_position.y -= m_dy;

	int xmax = (int)m_position.x + (int)TEXTUREMANAGER.getTextureInfo( m_texture ).Width;
	int ymax = (int)m_position.y + (int)TEXTUREMANAGER.getTextureInfo( m_texture ).Height;
	m_odometer += m_speed;

	if( xmax < 0 || ymax < 0 || 
		m_position.x > GAME_WIDTH || m_position.y > GAME_HEIGHT ) {
			GAMEENGINE.removeActor( this );
	}

	GAMEENGINE.registerCollidable(this);
}

void Bullet::draw( void ) {
	// Draws a trail based on speed
	// I wrote it at 2 AM and as far as I know it works based on black magic
	int length = T_LEN * m_speed;
	if( length > m_odometer )
		length = m_odometer;
	for( int i = length; i >= 0; --i ){
		float movscale = static_cast<float> (i)/static_cast<float> (m_speed);
		float colscale = static_cast<float> (i)/static_cast<float> (length);
		D3DXVECTOR2 pos(m_position.x, m_position.y);
		pos.x -= m_dx*movscale ;
		pos.y += m_dy*movscale ;
		// Switch color between blue/red depending on power
		D3DXCOLOR col = (m_damage > 1)? D3DXCOLOR(1.0,1.0-colscale,1.0-colscale,1.0-colscale) : 
										D3DXCOLOR(1.0-colscale,1.0-colscale,1.0,1.0-colscale);
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( m_texture ), 
			NULL,
			&m_center,
			&pos,
			NULL,
			m_rot,
			col
			);
	}
}

int Bullet::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( m_texture ).Width;
}

int Bullet::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( m_texture ).Height;
}