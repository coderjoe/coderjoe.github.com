#include "stdafx.h"
#include "AnimTest.h"
#include "GFXManager.h"
#include "GameEngine.h"

AnimTest::AnimTest(void)
{
	m_position.x = 0;
	m_position.y = 400;

	alpha = 1.0;

	// Collision parameters
	points.push_back(D3DXVECTOR2(0,0));
	points.push_back(D3DXVECTOR2(200,0));
	points.push_back(D3DXVECTOR2(200,200));
	points.push_back(D3DXVECTOR2(0,200));

	type = foe; //we're an enemy
}

AnimTest::~AnimTest(void)
{
}

void AnimTest::draw(){

	//darw our frames
	static int counter = 0;
	static float xindex=0, yindex=0, rotation=0;
	static float r=.5, g=.25, b=.125;
	static float rx=.004, gx=.003, bx=.002;
	counter++;

	r+=rx; 	g+=gx;	b+=bx;
	if( r > 1.0 || r < 0) { rx = -rx; r+= rx; }
	if( g > 1.0 || g < 0) { gx = -gx; g+= gx; }
	if( b > 1.0 || b < 0) { bx = -bx; b+= bx; }

	//if( counter >=60 ){
		rotation += .2;
		if( rotation >= 360 ) {
			rotation = 0.0;
		}
		counter = 0;
		xindex++;
		if( xindex >= 4 ){
			xindex = 0;
			yindex++;
		}
	//}
	yindex = (yindex >=4)? 0 : yindex;
	
	RECT rect;
	rect.top = yindex*200;
	rect.left = xindex*200;
	rect.bottom = rect.top+199;
	rect.right = rect.left+199;

	static D3DXVECTOR2 pos = D3DXVECTOR2( 0, 400 );
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture(texture), 
					&rect,
					&D3DXVECTOR2( 100, 100 ),
					&pos,
					NULL,
					rotation,
					D3DXCOLOR(r, g, b, alpha));

}

void AnimTest::tick(){
	//tick our location and colors
	if( collided ){
		collided = false;
		alpha -= .05;
		alpha = (alpha < 0)?1.0:alpha;
	}

	GAMEENGINE.registerCollidable(this);
}