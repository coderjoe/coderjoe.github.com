#include "stdafx.h"
#include "TextureManager.h"

TextureManager::TextureManager() {
}

TextureManager::~TextureManager() {
}

void TextureManager::loadTextures() {
	D3DSURFACE_DESC		tempBitmapInfo;
	D3DXIMAGE_INFO		tempImageInfo;
	
	LPDIRECT3DTEXTURE9	tempTexture = NULL;
	
	m_bTexturesLoaded = true;

	for( int i = 0; i < TEXTURE_COUNT; i++ ) {
		D3DXGetImageInfoFromFile( TextureManager_texturelist[i], &tempImageInfo );

		D3DXCreateTextureFromFileEx(
			D3DMANAGER.getDevice(), 
			TextureManager_texturelist[ i ],
			tempImageInfo.Width,
			tempImageInfo.Height, 
			tempImageInfo.MipLevels,
			0, 
			D3DFMT_UNKNOWN,
			D3DPOOL_MANAGED,
			D3DX_FILTER_NONE,
			D3DX_FILTER_NONE,
			0,
			NULL,
			NULL,
			&tempTexture
		);

		tempTexture->GetLevelDesc( 0, &tempBitmapInfo );

		m_vTextureInfo.push_back( tempImageInfo );
		m_vTextures.push_back( tempTexture );
	}
}

void TextureManager::killTextures() {
	LPDIRECT3DTEXTURE9	tempTexture;

	// Release the textures
	for( unsigned int i = 0; i < m_vTextures.size(); i++ ) {
		tempTexture = m_vTextures.at( i );
		if( tempTexture ) {
			tempTexture->Release();
		}
	}

	m_vTextureInfo.clear();
	m_vTextures.clear();

	m_bTexturesLoaded = false;
}

LPDIRECT3DTEXTURE9 TextureManager::getTexture( int index ) {
	if( m_bTexturesLoaded ) {
		return m_vTextures.at( index );
	} else {
		return NULL;
	}
}

D3DXIMAGE_INFO TextureManager::getTextureInfo( int index ) {
	if( m_bTexturesLoaded ) {
		return m_vTextureInfo.at( index );
	}

	return D3DXIMAGE_INFO();
}