#include "stdafx.h"
#include "MoveLeft.h"


// Moves a specified object to the left, based on speed
MoveLeft::MoveLeft( Collidable * obj, double speed )
: Movement( obj, speed ) {
}

MoveLeft::~MoveLeft() {
}

// Performs the movement
void MoveLeft::move() {
	D3DXVECTOR2 m_pos = m_obj->getPosition();

	m_pos.x = m_pos.x - m_speed;

	m_obj->setPosition( m_pos );
}