#pragma once
#include "Singleton.h"
#include <vector>

#define SINTABLE SinTable::Instance()

class SinTable :
	public Singleton<SinTable>
{
	friend class Singleton<SinTable>;

protected:
	SinTable(void);
	~SinTable(void);

public:
	std::vector<float> getSinTable();
	std::vector<float> getCosTable();

private:
	std::vector<float> sinTable;
	std::vector<float> cosTable;
};
