/*
 * Helicopter left defines a helicopter initially moving left
 */
#ifndef _HELICOPTERLEFT_H_
#define _HELICOPTERLEFT_H_

#include "Enemy.h"

class HelicopterLeft : public Enemy {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	// Constructor and destructor
	HelicopterLeft();
	~HelicopterLeft();

	//Set position override from collidable
	void setPosition( double x, double y );
	
	//set the direction for thi Helicopter
	void setDirection( int d );

	//Get width and height override from actor
	int getWidth();
	int getHeight();

	//tick and draw override from actor
	void tick();
	void draw();
private:
	int m_dx; //change in X modifier
	int m_dy; //change in Y modifier
	int rotate; //rotation
};

#endif