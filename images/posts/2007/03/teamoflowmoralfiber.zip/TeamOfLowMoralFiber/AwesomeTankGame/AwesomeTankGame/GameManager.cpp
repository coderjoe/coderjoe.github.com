#include "stdafx.h"
#include "Tank.h"
#include "GFXManager.h"
#include "D3DManager.h"
#include "InputManager.h"
#include "Actor.h"

GameManager::GameManager(void)
{
	int score = 0;
	int multiplier = 1;
	int kills_to_mult = 0;
	int ticks_to_mult_gone = 0;
	Actor actorArray[20];
}

GameManager::~GameManager(void)
{
}

void GameManager::init(){
	Player = TANK();

	actorArray[0] = Player;
}

void GameManager::addActor(Actor){
	added = false;
	
	for(int i=0; i<20; i++)
	{
		if((actorArray[i] == null || actorArray[i] == "") && added == false)
		{
			actorArray[i] = Actor;

			added = true;
		}
	}
}

void GameManager::tick(){
	for(int i=0; i<20; i++)
	{
		actorArray[i].tick();		
	}
}

void GameManager::draw(){
	D3DXVECTOR2 pos;
		pos.x = static_cast<float>(x);
		pos.y = static_cast<float>(y);
		
		D3DXVECTOR2 center( (float)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Width/2, 
							(float)TEXTUREMANAGER.getTextureInfo( TEX_TANK ).Height/2);

		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_TANK ) , 
			NULL,
			&center,
			&pos,
			&D3DXVECTOR2( 0.5, 0.5 ),
			rot, 
			D3DCOLOR_RGBA(255,255,255,255));

		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_DEBUG_ARROW ),
			NULL,
			NULL,
			&pos );

		

		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_DEBUG_ARROW ),
			NULL,
			NULL,
			&D3DXVECTOR2( pos.x + center.x, pos.y + center.y ) );

		
}