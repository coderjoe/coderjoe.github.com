#include "stdafx.h"
#include "Actor.h"


act_t Actor::getType(){
	return type;
}

object_t Actor::getObjectType(){
	return obj_type;
}