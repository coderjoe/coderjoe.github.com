/*
 * Level actors stores the actor list to spin through and spawn oncommand
 */
#ifndef _LEVELACTORS_H_
#define _LEVELACTORS_H_

#include <string>
#include <vector>
#include <iostream>
#include <fstream>

class LevelActors {
private:
	//struct for actor info.
	struct ActorInfo {
		std::string name;
		int x; //x y spawn
		int y; 

		//Actor info constructor
		ActorInfo( std::string s, int ix, int iy ) {
			name = s;
			x = ix;
			y = iy;
		}
	};

	//Defining an itnerval. An interval is decremented, when 0
	//its stuff is spawned
	struct IntervalInfo {
		std::vector< ActorInfo > actors;
		int interval;
		int interval_size;

		IntervalInfo() {
			interval = 0;
			interval_size = 0;
		}

		IntervalInfo( int i ) {
			interval = i;
			interval_size = i;
		}

		void reset() {
			interval = interval_size;
		}
	};

public:
	//Constructor which takes in a filename
	LevelActors( std::string filename );
	//destructor
	~LevelActors();

	//tick to the next set
	void tick();
private:
	std::vector< IntervalInfo >	m_vIntervals; //hold the intervals
	int							m_iInterval; //the current interval
};

#endif