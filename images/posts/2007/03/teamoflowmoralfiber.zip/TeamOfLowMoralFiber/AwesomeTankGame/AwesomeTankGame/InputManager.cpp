/*
 * NOTE: See DKeyboard.h for additional info about this file and the origines of the code contained within.
 */

#include "stdafx.h"
#include "GameEngine.h"
#include "InputManager.h"

DInputManager::DInputManager() {
	for( int i = 0; i < 256; i++ ) {
		m_keys[i] = 0;
	}
	
	m_keyboard = NULL;
	m_mouseLoc.x = GAME_WIDTH / 2;
	m_mouseLoc.y = GAME_HEIGHT / 2;
}

DInputManager::~DInputManager() {
	ReleaseInputDevices();
}

bool DInputManager::SetupInputDevices() {
	HRESULT r;
	
	DirectInput8Create( GAMEWINDOW.hInstance(), 
		DIRECTINPUT_VERSION,
		IID_IDirectInput8,
		(void**)&m_input,
		NULL
	);

	//make keyboard device
	r = m_input->CreateDevice(GUID_SysKeyboard, &m_keyboard, NULL);
	if ( FAILED( r ) ) {
		return false;
	}

	//Set Data Format
	r = m_keyboard->SetDataFormat( &c_dfDIKeyboard );
	if ( FAILED( r ) ) {
		return false;
	}

	//Set Coop Level
	r = m_keyboard->SetCooperativeLevel( GAMEWINDOW.hWnd() ,
		DISCL_FOREGROUND | DISCL_NONEXCLUSIVE );
	if ( FAILED( r ) ) {
		return false;
	}

	//Acquire
	r = m_keyboard->Acquire();
	if ( FAILED( r ) ) {
		return false;
	}

	//make mouse device
	r = m_input->CreateDevice(GUID_SysMouse, &m_mouse, NULL);
	if ( FAILED( r ) ) {
		return false;
	}

	//Set Data Format
	r = m_mouse->SetDataFormat(&c_dfDIMouse);
	if ( FAILED( r ) ) {
		return false;
	}

	//Set Coop Level
	r = m_mouse->SetCooperativeLevel( GAMEWINDOW.hWnd() , DISCL_FOREGROUND | DISCL_EXCLUSIVE);
	if ( FAILED( r ) ) {
		return false;
	}

	//Acquire
	r = m_mouse->Acquire();
	if ( FAILED( r ) ) {
		return false;
	} 

	return true;
}

void DInputManager::ReleaseInputDevices() {
	if (m_keyboard) {
		m_keyboard->Unacquire();
		m_keyboard->Release();
		m_keyboard = NULL;
	}

	if (m_mouse) {
		m_mouse->Unacquire();
		m_mouse->Release();
		m_mouse = NULL;
	}
}

bool DInputManager::UpdateMousePosition() {
	HRESULT r = 0;

	if( m_mouse ) {
		r = m_mouse->GetDeviceState( sizeof( DIMOUSESTATE ), &mouse_state );
	} else {
		return FALSE;
	}

	if ( FAILED( r ) ) {

		if(r == DIERR_INPUTLOST) {

			while(r == DIERR_INPUTLOST) {
				r = m_mouse->Acquire();

				if(SUCCEEDED( r ) ) {
					m_mouse->GetDeviceState( sizeof( DIMOUSESTATE ), &mouse_state );
				} else {
					return FALSE;
				}
			}
		}
		
		else if (r == DIERR_NOTACQUIRED)
		{
				r = m_mouse->Acquire();
				if (SUCCEEDED( r ) )
				{
					m_mouse->GetDeviceState( sizeof( DIMOUSESTATE ), &mouse_state );
				} else {
					return FALSE;
				}
		}
		else
			//some other keyboard error..otherwise return false
			return FALSE;
	}


	m_mouseLoc.x += mouse_state.lX;
	m_mouseLoc.y += mouse_state.lY;

	if( m_mouseLoc.x < 0 )
		m_mouseLoc.x = 0;
	
	if( m_mouseLoc.x > D3DMANAGER.getWidth() )
		m_mouseLoc.x = D3DMANAGER.getWidth();

	if( m_mouseLoc.y < 0 )
		m_mouseLoc.y = 0;
	
	if( m_mouseLoc.y > D3DMANAGER.getHeight() )
		m_mouseLoc.y = D3DMANAGER.getHeight();

	//ScreenToClient( GAMEWINDOW.hWnd(), &m_mouseLoc );
	return TRUE;
}

bool DInputManager::MouseCurrentPosition(int & xPos, int & yPos)
{
	xPos = m_mouseLoc.x;
	yPos = m_mouseLoc.y;

  return true;
}

bool DInputManager::MouseIsLeftDown()
{
	if(mouse_state.rgbButtons[0] & 0x80){
		return true;
	}else{
		return false;
	}
}

bool DInputManager::MouseIsRightDown()
{
	if(mouse_state.rgbButtons[1] & 0x80){
		return true;
	}else{
		return false;
	}
}

bool DInputManager::IsKeyDown(int key)
{
	HRESULT r = 0;
	//Get the state of the keyboard in the buffer
	r = m_keyboard->GetDeviceState( sizeof( m_keys ), &m_keys );
	if ( FAILED( r ) ) {

		if(r == DIERR_INPUTLOST) {

			while(r == DIERR_INPUTLOST) {
				r = m_keyboard->Acquire();

				if(SUCCEEDED( r ) ) {
					m_keyboard->GetDeviceState( sizeof( m_keys ), &m_keys );
				} else {
					return FALSE;
				}
			}
		}
		
		else if (r == DIERR_NOTACQUIRED)
		{
				r = m_keyboard->Acquire();
				if (SUCCEEDED( r ) )
				{
					m_keyboard->GetDeviceState( sizeof( m_keys ), &m_keys );
				} else {
					return FALSE;
				}
		}
		else
			//some other keyboard error..otherwise return false
			return FALSE;
	}

	//check for the KEY !!
	if( m_keys[key] & 0x80 )
		return TRUE;
	else
		return FALSE;

}