#ifndef _GAMEWINDOW_H_
#define _GAMEWINDOW_H_

#include <d3d9.h>
#include "Singleton.h"

#define GAMEWINDOW GameWindow::Instance()

// Functions related to setting up a Window and handling that crazy Windows stuff
class GameWindow : public Singleton<GameWindow> {
	friend class Singleton<GameWindow>;
protected:
	GameWindow();
	~GameWindow();
public:
	// Handle window creation and display
	void setupWindow( HINSTANCE hInst );
	bool createWindow();
	// Shut down our window
	bool destroyWindow();

	// Windows stuff people may need
	HINSTANCE & hInstance();
	HWND & hWnd();

	void setDimensions( int w, int h );

private:
	LPCTSTR m_sWinClass;
	WNDCLASSEX m_wc;

	HINSTANCE m_hInstance;
	HWND m_hWnd;

	int m_width;
	int m_height;
};

LRESULT CALLBACK GlobalWinProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam );

#endif