#ifndef _MOVEAROUNDPOINT_H_
#define _MOVEAROUNDPOINT_H_

#include "Movement.h"
#include "Collidable.h"

// Moves an object around a point
class MoveAroundPoint : public Movement {
public:
	MoveAroundPoint( Collidable * obj, double speed, D3DXVECTOR2 point, int direction = 1 );
	virtual ~MoveAroundPoint();

	// initializes the movement
	virtual void initMove();
	// calculates and performs the movement
	virtual void move();
private:
	D3DXVECTOR2		m_startingPoint;
	D3DXVECTOR2		m_aroundPoint;
	D3DXVECTOR2		m_adjustPoint;
	double			m_rot;
	int				m_direction;
};

#endif