/*
** TestEnemyLeft defines a test enemy which moves left
** This is a test class, please do not use in production code
**
 */
#ifndef _TESTENEMYLEFT_H_
#define _TESTENEMYLEFT_H_

#include "Collidable.h"

class TestEnemyLeft : public Collidable {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	//Constructor and destructor
	TestEnemyLeft();
	~TestEnemyLeft();

	//set position override from Actor
	void setPosition( double x, double y );
	//set direction changes the direction of the movement
	void setDirection( int d );

	//get width and height override from actor
	int getWidth();
	int getHeight();

	//tick override from actor
	void tick();
	//draw override from actor
	void draw();
private:
	int m_dx; //change in x per tick
	int m_dy; //change in y per tick
	int rotate; //rotation of turret
};

#endif