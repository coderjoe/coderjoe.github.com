#include "stdafx.h"
#include "d3dx9.h"
#include "ActorFactory.h"
#include "TestEnemy.h"
#include "Bullet.h"
#include "Helicopter.h"
#include "HelicopterLeft.h"
#include "StationaryTurret.h"
#include "HorizontalTank.h"
#include "HorizontalTankLeft.h"
#include "VerticalBike.h"
#include "Explosion.h"
#include "MLHelicopter.h"

#include "Movement.h"
#include "MoveLeft.h"
#include "MoveRight.h"
#include "MoveAroundPoint.h"


Actor * ActorFactory::CreateActorAt( std::string type, int x, int y ) {
	/*
	 * Identifiers are described in classes except for movement lists
	 * the movement lists define their movements
	 * 
	 */
	if( type == TestEnemy::IDENTIFIER ) {
		TestEnemy * e = new TestEnemy();
		e->setPosition( x, y );
		return e;
	} else if( type == Helicopter::IDENTIFIER ) {
		Helicopter * e = new Helicopter();
		e->setPosition( x, y );
		return e;
	} else if( type == HelicopterLeft::IDENTIFIER ) {
		HelicopterLeft * e = new HelicopterLeft();
		e->setPosition( x, y );
		return e;
	} else if( type == StationaryTurret::IDENTIFIER ) {
		StationaryTurret * e = new StationaryTurret();
		e->setPosition( x, y );
		return e;
	} else if( type == HorizontalTank::IDENTIFIER ) {
		HorizontalTank * e = new HorizontalTank();
		e->setPosition( x, y );
		return e;
	} else if( type == HorizontalTankLeft::IDENTIFIER ) {
		HorizontalTankLeft * e = new HorizontalTankLeft();
		e->setPosition( x, y );
		return e;
	} else if( type == VerticalBike::IDENTIFIER ) {
		VerticalBike * e = new VerticalBike();
		e->setPosition( x, y );
		return e;
	} else if( type == Explosion::IDENTIFIER ) {
		Explosion * e = new Explosion();
		e->setPosition( x, y );
		return e;
	} else if( type == "MLHELICOPTER_RECTLOOP_RIGHT" ) {
		//Does a rectangular loop going right
		MLHelicopter * e = new MLHelicopter();
		e->setPosition( x, y );

		//Enter Screen
		e->getMovementList().newSet();
		e->getMovementList().setDuration((GAME_WIDTH/2)-50);
		e->getMovementList().addMovement( new MoveRight(e,2) );
		//rotate back
		e->getMovementList().newSet();
		e->getMovementList().setDuration(95);
		e->getMovementList().addMovement( new MoveAroundPoint(e,2,D3DXVECTOR2(0,50) ) );
		//go left again
		e->getMovementList().newSet();
		e->getMovementList().setDuration((GAME_WIDTH/2)-150);
		e->getMovementList().addMovement( new MoveLeft(e,2 ) );
		//rotate up
		e->getMovementList().newSet();
		e->getMovementList().setDuration(95);
		e->getMovementList().addMovement( new MoveAroundPoint(e,2,D3DXVECTOR2(0,-50) ) );
		//go right off screen
		e->getMovementList().newSet();
		e->getMovementList().setDuration(GAME_WIDTH);
		e->getMovementList().addMovement( new MoveRight(e,2) );

		return e;
	} else if( type == "MLHELICOPTER_RECTLOOP_LEFT" ) {
		//does a rectangular loop going left
		MLHelicopter * e = new MLHelicopter();
		e->setPosition( x, y );
		//Enter Screen
		e->getMovementList().newSet();
		e->getMovementList().setDuration((GAME_WIDTH/2)-50);
		e->getMovementList().addMovement( new MoveLeft(e,2) );
		//rotate back
		e->getMovementList().newSet();
		e->getMovementList().setDuration(95);
		e->getMovementList().addMovement( new MoveAroundPoint(e,-2,D3DXVECTOR2(0,50) ) );
		//go left again
		e->getMovementList().newSet();
		e->getMovementList().setDuration((GAME_WIDTH/2)-150);
		e->getMovementList().addMovement( new MoveRight(e,2 ) );
		//rotate up
		e->getMovementList().newSet();
		e->getMovementList().setDuration(95);
		e->getMovementList().addMovement( new MoveAroundPoint(e,-2,D3DXVECTOR2(0,-50) ) );
		//go right off screen
		e->getMovementList().newSet();
		e->getMovementList().setDuration(GAME_WIDTH);
		e->getMovementList().addMovement( new MoveLeft(e,2) );
		return e;
	} else if( type == "MLHELICOPTER_BIGLOOP_LEFT" ) {
		//does a single big loop going left
		MLHelicopter * e = new MLHelicopter();
		e->setPosition( x, y );
		//Enter Screen
		e->getMovementList().newSet();
		e->getMovementList().setDuration((GAME_WIDTH/4));
		e->getMovementList().addMovement( new MoveLeft(e,2) );
		//rotate back
		e->getMovementList().newSet();
		e->getMovementList().setDuration(370);
		e->getMovementList().addMovement( new MoveAroundPoint(e,-1,D3DXVECTOR2(0,200) ) );
		//go right off screen
		e->getMovementList().newSet();
		e->getMovementList().setDuration(GAME_WIDTH);
		e->getMovementList().addMovement( new MoveLeft(e,2) );
		return e;
	}
	return NULL;
}