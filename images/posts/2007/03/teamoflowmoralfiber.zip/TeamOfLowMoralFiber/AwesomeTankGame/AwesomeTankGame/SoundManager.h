#pragma once

#include "Singleton.h"
#include "fmod/fmod.hpp"


#define SOUNDMANAGER SoundManager::Instance()


// Handles playing of sound.  Done with fmod, and was pretty easy (the second time)
class SoundManager : public Singleton<SoundManager> {
	friend class Singleton<SoundManager>;

protected:
	SoundManager(void);
	// Setup and destrust stuff
	void InitAudio();
	void KillAudio();
	
public:
	~SoundManager(void);
	// Play a sound with looping and volume
	FMOD::Channel* Play( char* filename, bool loop  = false, float volume = 1.0);
	// Get the system for more detailed sound stuff
	FMOD::System* getSystem();

private:
	FMOD::System* sys;
	
};
