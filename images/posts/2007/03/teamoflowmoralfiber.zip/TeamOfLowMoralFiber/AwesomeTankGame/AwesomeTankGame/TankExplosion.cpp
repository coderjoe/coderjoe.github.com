#include "stdafx.h"
#include "GameEngine.h"
#include "TankExplosion.h"
#include "GfxManager.h"
#include "TextureManager.h"

TankExplosion::TankExplosion() : Explosion() {
	m_scaling = D3DXVECTOR2(2.0,2.0);
}

TankExplosion::~TankExplosion() {
}

void TankExplosion::draw() {
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture( m_texture ),
					&m_frameRect, NULL, &m_position, &m_scaling );
}

int TankExplosion::getWidth() {
	return (TEXTUREMANAGER.getTextureInfo( m_texture ).Width * m_scaling.x);
}

int TankExplosion::getHeight() {
	return (TEXTUREMANAGER.getTextureInfo( m_texture ).Height * m_scaling.x);
}

void TankExplosion::endExplosion() {
	GAMEENGINE.removeActor( this );
	GAMEENGINE.endGame();
}