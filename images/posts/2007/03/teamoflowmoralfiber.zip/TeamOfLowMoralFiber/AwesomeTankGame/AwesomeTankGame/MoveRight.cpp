#include "stdafx.h"
#include "MoveRight.h"

// Moves an object to the right depending on speed
MoveRight::MoveRight( Collidable * obj, double speed ) 
: Movement( obj, speed ) {
}

MoveRight::~MoveRight() {
}

// Performs the movement
void MoveRight::move() {
	D3DXVECTOR2 m_pos = m_obj->getPosition();

	m_pos.x = m_pos.x + m_speed;

	m_obj->setPosition( m_pos );
}