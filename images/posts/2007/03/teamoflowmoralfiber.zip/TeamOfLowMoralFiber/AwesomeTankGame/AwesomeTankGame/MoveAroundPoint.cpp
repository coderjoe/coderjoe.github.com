#include "stdafx.h"
#include "MoveAroundPoint.h"
#include "SinTable.h"
#include "TextureManager.h"
#include "GfxManager.h"

// Makes the object specified move around a point, given a speed and direction
MoveAroundPoint::MoveAroundPoint( Collidable * obj, double speed, D3DXVECTOR2 adjust, int direction )
: Movement( obj, speed ) {
	// Sets up the movement variables
	m_startingPoint = obj->getPosition();
	m_adjustPoint = adjust;
	m_aroundPoint.x = m_startingPoint.x + adjust.x;
	m_aroundPoint.y = m_startingPoint.y + adjust.y;

	m_direction = direction;
	m_rot = 0;
}

MoveAroundPoint::~MoveAroundPoint() {
}

void MoveAroundPoint::initMove() {
	// Determines calculations for the movement
	m_startingPoint = m_obj->getPosition();

	m_aroundPoint.x = m_startingPoint.x + m_adjustPoint.x;
	m_aroundPoint.y = m_startingPoint.y + m_adjustPoint.y;
}

void MoveAroundPoint::move() {
	// Does the calculations for the actual moving, and moves the object
	float sinOf = sin( D3DXToRadian(m_rot) );
	float cosOf = cos( D3DXToRadian(m_rot) );

	D3DXMATRIX ident, matrix, rotMatrix, result;
	D3DXMatrixIdentity( &ident );
	D3DXMatrixIdentity( &matrix );
	D3DXMatrixIdentity( &rotMatrix );
	
	D3DXMatrixRotationZ( &rotMatrix, D3DXToRadian( m_rot ) );

	D3DXVECTOR2 p,r;
	p.x = m_startingPoint.x - m_aroundPoint.x;
	p.y = m_startingPoint.y - m_aroundPoint.y;

	r.x = ( p.x*cosOf ) - ( p.y*sinOf );
	r.y = ( p.x*sinOf ) + ( p.y*cosOf );
	
	D3DXVECTOR2 pos;
	pos.x = r.x + m_aroundPoint.x;
	pos.y = r.y + m_aroundPoint.y;

	m_obj->setPosition( pos );

	m_rot = m_rot + (m_speed*m_direction);
	if( m_rot < 0 ) {
		m_rot = 360 + m_rot;
	} else if ( m_rot > 360 ) {
		m_rot = 360 - m_rot;
	}
}