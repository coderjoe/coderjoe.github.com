#ifndef _GAMEENGINE_H_
#define _GAMEENGINE_H_

#include "Singleton.h"
#include "Statistics.h"
#include "TextureManager.h"
#include "GameWindow.h"
#include "InputManager.h"
#include "Level.h"
#include "Collidable.h"
#include <vector>
#include "AnimTest.h"
#include "Tank.h"
#include "Powerup.h"
#include "MainMenu.h"
#include "YouDiedMenu.h"


#define DEFAULT_WIDTH		1024 //screen size
#define DEFAULT_HEIGHT		768
#define GAME_WIDTH			824  // playable area size
#define GAME_HEIGHT			768
#define BIN_WIDTH			8	// bins are 128x128
#define BIN_HEIGHT			6

// how many enemies for a multiplier bar
#define MULTIPLIER_INTERVAL 30

#define DEFAULT_FULLSCREEN	false
#define DEFAULT_D3DFMT		D3DFMT_R5G6B5

#define GAMEENGINE GameEngine::Instance()

// Runs all game logic.  details follow
class GameEngine : public Singleton<GameEngine>{
	friend class Singleton<GameEngine>;
protected:
	GameEngine();
	~GameEngine();
public:
	// initialization
	void init( HINSTANCE hInstance );
	void restartGame();

	// handle input
	void initKeyboard();
	void killKeyboard();

	// tick all actors and ui
	void tick();
	// draw all actors and ui
	void draw();

	void drawUI();

	// add an actor to the list of things to draw
	void addActor( Actor *act );
	// remove an actor from the list of things to draw, and delete it
	void removeActor( Actor *act );
	// remove all actors
	void clearActors();
	// make an actor active in collision detection
	void registerCollidable( Collidable *coll );
	// get the tank player object
	Tank* getTank();

	// change te score
	void updateScore( int increase );
	// get the score
	int getScore();
	// set the active powerup
	void setPowerup( powerup_t ptype );

	// begin running game logic
	void startGame();
	// quit the game
	void endGame();
	void quitGame();
	// is the player dead?
	bool isDead();

	// what level are we on?
	Level * getLevel();

private:
	// state info
	bool					m_startedPlaying;
	bool					m_died;
	bool					m_paused;
	clock_t					m_lastPause;

	int						score;
	int						multiplier;
	int						killCounter;

	Powerup*				m_powerup;

	HINSTANCE				m_hInstance;
	Level					*m_pLevel;
	// Collision bins
	std::vector<Collidable*> friendBins[BIN_WIDTH][BIN_HEIGHT];
	std::vector<Collidable*> foeBins[BIN_WIDTH][BIN_HEIGHT];
	std::vector<Collidable*> neutralBins[BIN_WIDTH][BIN_HEIGHT];
	// draw/tick bins
	std::vector<Actor*>		friendlies;
	std::vector<Actor*>		foes;
	std::vector<Actor*>		neutrals;
	// mouse
	D3DXVECTOR2				m_mouseCenter;

	// menus
	Actor					*m_mainMenu;
	Actor					*m_youDiedMenu;

};

#endif
