#pragma once
#include "Actor.h"
#include <vector>
#include "d3dx9math.h"

// Defines things that can be hit.  They have it boxes and get told when something has hit them.
class Collidable :
	public Actor
{
public:
	Collidable(void);
	virtual ~Collidable(void);

	// Get the hit box for this thing
	std::vector<D3DXVECTOR2> getPoints();
	// Where is it?
	D3DXVECTOR2 getPosition();
	void setPosition( D3DXVECTOR2 nPos );

	// Check if we hit this other obect being sent to us
	void collide( std::vector<Collidable*> );
	// Defines what to do if you hit this other object.  Should be overridden for most Actors
	virtual void setCollided( Collidable* other );
protected:
	// Hit box
	std::vector<D3DXVECTOR2>	points;
	D3DXVECTOR2					m_position;
	int							m_health;

	// Have we hit anything?
	bool collided;
};

// The meat of the Collision detection code.  Based on "Collision Detection in Lingo" by Andy Phelps
bool checkIntersection( D3DXVECTOR2 a, D3DXVECTOR2 b, D3DXVECTOR2 c, D3DXVECTOR2 d,  D3DXVECTOR2 offset1, D3DXVECTOR2 offset2  );