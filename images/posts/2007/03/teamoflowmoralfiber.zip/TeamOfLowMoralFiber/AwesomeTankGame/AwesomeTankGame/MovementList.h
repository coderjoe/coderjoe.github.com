#ifndef _MOVEMENT_LIST_H_
#define _MOVEMENT_LIST_H_

#include "Movement.h"
#include <vector>

// Keeps track of a list of movements and triggers the movements
class MovementList {
public:
	struct MovementInfo {
		int		duration;
		std::vector< Movement * >	movements;

		MovementInfo() {
			duration = 0;
		}
	};

public:
	MovementList();
	virtual ~MovementList();

	void newSet();
	void setDuration( int d );
	void addMovement( Movement * m );

	void doMovements();

	bool isDone();

private:
	std::vector<MovementInfo*>	m_list;
	int m_counter;
	int m_currentIndex;
	bool m_done;
};

#endif