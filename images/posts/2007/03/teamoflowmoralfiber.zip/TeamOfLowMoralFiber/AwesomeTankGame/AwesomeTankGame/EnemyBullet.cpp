#include "stdafx.h"
#include "EnemyBullet.h"

EnemyBullet::EnemyBullet(float x, float y, float rot, int damage_mult )
: Bullet( x, y, rot, damage_mult ) {
	m_texture = TEX_BULLET_ROUND2; //set our texture
	type = foe; //we are an enemy
	obj_type = fo_bullet; //which is a bullet
	
	m_speed = 3; //set our movement speed
	setRotation( rot ); //set our rotation

	m_center.x = static_cast<float> ( TEXTUREMANAGER.getTextureInfo( m_texture ).Width / 2);
	m_center.y = static_cast<float> ( TEXTUREMANAGER.getTextureInfo( m_texture ).Height / 2);

	//set our collision parameters
	points.push_back(D3DXVECTOR2(2,2));
	points.push_back(D3DXVECTOR2(18,0));
	points.push_back(D3DXVECTOR2(18,18));
	points.push_back(D3DXVECTOR2(0,18));
}

EnemyBullet::~EnemyBullet() {
}

void EnemyBullet::setCollided( Collidable *other ) {
	//if we hit the tank, set ourselves as collided
	if( other->getObjectType() == tank ) {
		collided = true;
	}
}