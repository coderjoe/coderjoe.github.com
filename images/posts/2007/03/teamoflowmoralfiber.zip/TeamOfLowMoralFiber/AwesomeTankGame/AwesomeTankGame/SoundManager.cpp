#include "SoundManager.h"

SoundManager::SoundManager(void)
{
	InitAudio();
}

SoundManager::~SoundManager(void)
{
	KillAudio();
}

void SoundManager::InitAudio(void){
	FMOD::System_Create( &sys );
	sys->init( 100, FMOD_INIT_NORMAL, 0 );
}

void SoundManager::KillAudio(){
	sys->release();
}

FMOD::Channel* SoundManager::Play( char* filename, bool loop, float volume ){
	// Make a sound
	FMOD::Sound *sound;
	sys->createSound(filename, FMOD_DEFAULT, 0, &sound);

	//set looping
	sound->setMode( (loop)? FMOD_LOOP_NORMAL : FMOD_LOOP_OFF );

	// set volume and play
	FMOD::Channel *channel;
	sys->playSound(FMOD_CHANNEL_FREE, sound, true, &channel);
	channel->setVolume(volume);
	channel->setPaused( false );

	return channel;
}

FMOD::System* SoundManager::getSystem(){
	return sys;
}

