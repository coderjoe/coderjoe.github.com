#ifndef _MOVERIGHT_H_
#define _MOVERIGHT_H_

#include "Movement.h"
#include "Collidable.h"

// Moves a specified object to the right based on speed
class MoveRight : public Movement {
public:
	MoveRight( Collidable * obj, double speed );
	virtual ~MoveRight();

	// performs the movement
	virtual void move();
private:
};

#endif