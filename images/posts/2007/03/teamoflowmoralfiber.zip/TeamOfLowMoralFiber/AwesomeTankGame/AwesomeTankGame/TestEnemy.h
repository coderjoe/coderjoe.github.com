/*
** Test enemy defines our test enemy for our collidable classes
** please do NOT use in production code
**/
#ifndef _TESTENEMY_H_
#define _TESTENEMY_H_

#include "Collidable.h"
#include "Movement.h"

class TestEnemy : public Collidable {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	// Constructor and destructor
	TestEnemy();
	~TestEnemy();

	// Set position override from Collidable
	void setPosition( double x, double y );
	// Set direction changes the direction
	void setDirection( int d );

	// Get width and height override with Actor
	int getWidth();
	int getHeight();

	// Tick override from actor
	void tick();
	// Draw override from actor
	void draw();
private:
	int m_dx; //change in x modifier
	int m_dy; //change in y modifier
	int rotate; //rotation
	Movement * m_move; //Movement test variable
};

#endif