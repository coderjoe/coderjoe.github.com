#ifndef _EXPLOSION_H_
#define _EXPLOSION_H_

#include <d3dx9.h>
#include <time.h>
#include "Collidable.h"

class Explosion : public Actor {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	Explosion();
	virtual ~Explosion();

	void setPosition( double x, double y );
	void setDirection( int d );

	// remove ourself
	virtual void endExplosion();

	virtual int getWidth();
	virtual int getHeight();

	virtual void tick();
	virtual void draw();
protected:
	// Draw info
	D3DXVECTOR2 m_position;
	RECT		m_frameRect;
	int			m_frameNum;
	int			m_frameCount;
	int			m_texture;
	int			m_textureWidth;
	int			m_textureHeight;

	int			m_frameSpeed;
	clock_t		m_prevTime;
};

#endif