#ifndef _HELICOPTER_H_
#define _HELICOPTER_H_

#include "Enemy.h"
#include <time.h>

class Helicopter : public Enemy {
public:
	//Identifier for the factory
	static const std::string IDENTIFIER;

	//Constructor and destructor
	Helicopter();
	~Helicopter();

	//Set position override from collidable
	void setPosition( double x, double y );
	
	//set the direction of this helicopter
	void setDirection( int d );

	//get width and height override from actor
	int getWidth();
	int getHeight();

	//tick and draw override from actor
	void tick();
	void draw();
private:
	int m_dx; //change in x modifier
	int m_dy; //change in y modifier

protected:
	int rotate; //rotation 
	clock_t		m_lastShot; //last time this enemy shot
};

#endif