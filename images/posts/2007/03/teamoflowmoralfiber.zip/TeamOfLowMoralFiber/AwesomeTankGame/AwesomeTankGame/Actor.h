#ifndef _ACTOR_H_
#define _ACTOR_H_

// Basic types of objects for binning
enum act_t { friendly, foe, neutral };
// Specific types of objects for colliding
enum object_t { tank, fr_bullet, fr_laser, fo_bullet, powerup, air_enemy, ground_enemy };

// This is the interface for everything that moves and draws itself in the game.
class Actor {
public:
	virtual ~Actor() {};

	// Draw yourself.  do it with calls to GFXManager
	virtual void draw() = 0;

	// Move, update animations, process input, handle collisions
	virtual void tick() = 0;
	
	// Needed for sizing functions.  Yes it's silly, do it anyway
	virtual int getWidth() = 0;
	virtual int getHeight() = 0;

	// functions for actor types defined above
	act_t getType();
	object_t getObjectType();
protected:
	// Our types
	act_t type;
	object_t obj_type;
};

#endif