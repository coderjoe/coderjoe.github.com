#include "stdafx.h"
#include "Laser.h"
#include "GFXManager.h"
#include "TextureManager.h"
#include "GameEngine.h"
#include "SinTable.h"

Laser::Laser(float x, float y, float rot )
{
	type = friendly;
	obj_type = fr_laser;


	// follow path to the end of the screen, that is where we stop
	m_rot = rot;
	m_fade = 1.0;
	m_dy = cos( D3DXToRadian(m_rot) );
	m_dx = sin( D3DXToRadian(m_rot) );

	float endx = x, endy = y;
	while( endx > -.01 && endx < GAME_WIDTH && endy > -.01 && endy < GAME_HEIGHT ){
		endx += m_dx;
		endy -= m_dy;
	}

	points.push_back(D3DXVECTOR2(x,y));
	points.push_back(D3DXVECTOR2(endx,endy));

	/* This is broken, so i'm being bad and hard coding it
	m_center.y = static_cast<float>(TEXTUREMANAGER.getTextureInfo(TEX_LASER).Height)/2;
	m_center.x = static_cast<float>(TEXTUREMANAGER.getTextureInfo(TEX_LASER).Width)/2.0;
	*/

	m_center.x = 5;
	m_center.y = .5;
}

Laser::~Laser(void)
{
}

// Nothing here, colliding means nothing to a laser
void Laser::setCollided( Collidable * other ){}

void Laser::draw(){
	// Draws from start to finish
	D3DXVECTOR2 start, finish;
	start = points[0];
	finish = points[1];
	static int loopstart = 0;
	int loop = loopstart;
	loopstart = (loopstart+30)%360;
	
	float x = start.x;
	float y = start.y;

	std::vector<float> table = SINTABLE.getSinTable();
	std::vector<float> ctable = SINTABLE.getCosTable();


	while( x > -.01 && x < GAME_WIDTH && y > -.01 && y < GAME_HEIGHT ){
		D3DXVECTOR2 pos = D3DXVECTOR2(x - (m_center.x * ctable[m_rot]), y + (m_center.y * table[m_rot]) );
		D3DXVECTOR2 offset = D3DXVECTOR2( (16 * table[loop] * m_dy) + (m_center.x * ctable[m_rot]),
										 (16 * table[loop] * m_dx) - (m_center.x * table[m_rot]) );
		float color = (table[loop] + 1)/2;
		float color2 = (table[(loop+180)%360] +1)/2;
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture(TEX_TINY_WHITE), NULL, NULL, &(pos+offset), &D3DXVECTOR2(2,2), 0, D3DXCOLOR(color, color, 1.0, m_fade) );
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture(TEX_LASER), NULL, &m_center, &pos, NULL, m_rot,D3DXCOLOR(1.0, 1.0, 1.0, m_fade) );
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture(TEX_TINY_WHITE), NULL, NULL, &(pos-offset), &D3DXVECTOR2(2,2), 0, D3DXCOLOR(color, color, 1.0, m_fade) );
		
		x += m_dx;
		y -= m_dy;
		loop = (loop+5)%360;
	}
}

void Laser::tick(){
	m_fade -= .01;
	if( m_fade < .01 ){
		GAMEENGINE.removeActor( this );
		return;
	}
	GAMEENGINE.registerCollidable( this );
}

int Laser::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( TEX_LASER ).Width;
}

int Laser::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( TEX_LASER ).Height;
}