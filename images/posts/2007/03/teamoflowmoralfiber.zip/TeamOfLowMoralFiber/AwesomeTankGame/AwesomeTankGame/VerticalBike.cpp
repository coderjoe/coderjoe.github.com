#include "stdafx.h"
#include "VerticalBike.h"
#include "D3DManager.h"
#include "SoundManager.h"
#include "GameEngine.h"
#include "Explosion.h"
#include "PowerUpFactory.h"

const std::string VerticalBike::IDENTIFIER = "VERTICAL";

VerticalBike::VerticalBike() {
	//Initialize the tyeps
	type = foe; //foe
	obj_type = ground_enemy; //we are not flying
	m_dx = 0;
	m_dy = 3;
	rotate = 0;
	m_score = 200; //score worth

	points.push_back(D3DXVECTOR2(0,0));
	points.push_back(D3DXVECTOR2(0,100));
	points.push_back(D3DXVECTOR2(60,0));
	points.push_back(D3DXVECTOR2(60,100));
}

VerticalBike::~VerticalBike() {
}

void VerticalBike::setPosition( double x, double y ) {
	m_position.x = x;
	m_position.y = y;
}

void VerticalBike::setDirection( int d ) {
	m_dx = d;
}

void VerticalBike::tick() {
	//unregister if collided
	if( collided ) {
		GAMEENGINE.removeActor(this);
		return;
	}

	//tick to our next position
	m_position.x = m_position.x + m_dx;
	m_position.y = m_position.y + m_dy;

	//check to see if we should bounce
	if( m_position.x >= GAME_WIDTH - TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width ||
		m_position.x <= 0 ) {
		m_dx = m_dx * -1;
	}

	//if we're offscreen we need to dock points and remove this
	if( m_position.y > GAME_HEIGHT ) {
		GAMEENGINE.removeActor( this );
		GAMEENGINE.updateScore( -100 );
		return;
	}

	//if we got to here we can register as collidable
	GAMEENGINE.registerCollidable(this);
}

void VerticalBike::draw() {
	
	//rotation calculations for the frame to draw
	if( rotate == 5 )
	{
		rotate = 0;
	}

	if( rotate == 0 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_VERTI_BIKE1 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 1 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_VERTI_BIKE2 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 2 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_VERTI_BIKE3 ),
					NULL, NULL, &m_position );
	}
	else if( rotate == 3 )
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_VERTI_BIKE4 ),
					NULL, NULL, &m_position );
	}
	else
	{
		GFXMANAGER.draw( TEXTUREMANAGER.getTexture( TEX_ENEMY_VERTI_BIKE5 ),
					NULL, NULL, &m_position );
	}

	rotate++;

}

int VerticalBike::getWidth() {
	//return the width of oru texture
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Width;
}

int VerticalBike::getHeight() {
	//return the height of our textuer
	return TEXTUREMANAGER.getTextureInfo( TEX_ENEMY_TURRET1_BASE ).Height;
}