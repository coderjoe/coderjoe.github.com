#ifndef _TEXTUREMANAGERTEXTURELIST_H_
#define _TEXTUREMANAGERTEXTURELIST_H_

#include <tchar.h>

/*
 * How to update this file
 *
 * Step 1: Add a constant at the bottom of the constant list for the texture's index
 * Step 2: Incriment the texture count
 * Step 3: Add the file name to the list of textures
 */

// The texture constant
//tank stuff
#define TEX_TANK 0
//font stuff
#define TEX_FONT_FUTURA 1
//map tiles
#define TEX_ROAD_BLANK1 2 
#define TEX_ROAD_BLANK2 3
#define TEX_ROAD_BLANK3 4
#define TEX_ROAD_LEFT	5
#define TEX_ROAD_RIGHT	6
#define TEX_ROAD_WHITE_BOTTOM 7
#define	TEX_ROAD_WHITE_TOP	8
#define TEX_ROAD_YELLOW	9
#define TEX_MAP_TREE 10
#define TEX_MAP_ROCK 11
#define TEX_MAP_GRASS 12
// Clouds
#define TEX_CLOUD1 13
#define TEX_CLOUD2 14
#define TEX_CLOUD3 15
#define TEX_CLOUD4 16
#define TEX_CLOUD5 17
#define TEX_CLOUD6 18
#define TEX_CLOUD7 19
#define TEX_CLOUD8 20
#define TEX_CLOUD9 21
#define TEX_CLOUD10 22
#define TEX_CLOUD11 23
#define TEX_CLOUD12 24
#define TEX_CLOUD13 25
#define TEX_CLOUD14 26
#define TEX_CLOUD15 27
#define TEX_CLOUD16 28
#define TEX_CLOUD17 29
#define TEX_CLOUD18 30
//Oil spills and other "pretty" stuff
#define TEX_CRACK_LARGE 31
#define TEX_CRACK_MEDIUM 32
#define TEX_CRACK_SMALL 33
#define TEX_CRACK_SMALL2 34
#define TEX_OILSTAIN1 35
#define TEX_OILSTAIN2 36
#define TEX_TREDMARK_LARGE 37
#define TEX_TREDMARK_MEDIUM 38
#define TEX_TREDMARK_SMALL 39
// FULL CLOUD
#define TEX_FULL_CLOUD 40
// Tank turret
#define TEX_TANK_TURRET 41
// Enemy Textures
#define TEX_ENEMY_TURRET1_BASE 42
#define TEX_ENEMY_TURRET1_TURRET 43
#define TEX_ENEMY_COPTER1 44
#define TEX_ENEMY_COPTER2 45
#define TEX_ENEMY_COPTER3 46
#define TEX_ENEMY_COPTER4 47
#define TEX_ENEMY_HORIZ_TANK1 48
#define TEX_ENEMY_HORIZ_TANK2 49
#define TEX_ENEMY_HORIZ_TANK3 50
#define TEX_ENEMY_HORIZ_TANK4 51
#define TEX_ENEMY_HORIZ_TANK5 52
#define TEX_ENEMY_VERTI_BIKE1 53
#define TEX_ENEMY_VERTI_BIKE2 54
#define TEX_ENEMY_VERTI_BIKE3 55
#define TEX_ENEMY_VERTI_BIKE4 56
#define TEX_ENEMY_VERTI_BIKE5 57
// Mouse Cursor
#define TEX_MOUSE_CURSOR 58
// explosions
#define TEX_EXPLOSION1 59
//Bullets
#define TEX_BULLET_ROUND1 60
#define TEX_BULLET_ROUND2 61
#define TEX_LASER 62
//Debug stuff
#define TEX_DEBUG_ARROW 63
#define TEX_TEST_FONT 64
#define TEX_TEST_ANIM 65
#define TEX_WHITE_BOX 66
//Many Uses
#define	TEX_TINY_WHITE 67
//HUD stuff
#define TEX_HUD_BASE 68
#define TEX_HUD_MULTIPLIER 69
//Powerup stuff
#define TEX_POW_SPEED 70
#define TEX_POW_FLAME 71
#define TEX_POW_TRI 72
#define TEX_POW_LASER 73
//Screens
#define TEX_SCREEN_MAIN_MENU 74
#define TEX_SCREEN_YOU_DIED 75

// The texture total
// make sure this is set to 1+ the last texture
#define TEXTURE_COUNT (TEX_SCREEN_YOU_DIED + 1)

static const LPCWSTR TextureManager_texturelist[] = {
	//TANK BOTTOM
	_T("images/tank_base.png"),
	//FONTS
	_T("images/font_map_futura.png"),
	//ROAD TILES
	_T("images/road_tiles/roadblank01.png"),
	_T("images/road_tiles/roadblank02.png"),
	_T("images/road_tiles/roadblank03.png"),
	_T("images/road_tiles/roadleft1-01.png"),
	_T("images/road_tiles/roadright1-01.png"),
	_T("images/road_tiles/roadwhite01bottom.png"),
	_T("images/road_tiles/roadwhite01top.png"),
	_T("images/road_tiles/roadyellow.png"),
	//TEMPORARY MAP TILES
	_T("images/temporary_tiles/tree.png"),
	_T("images/temporary_tiles/rocks.png"),
	_T("images/temporary_tiles/grass.png"),
	//CLOUDS
	_T("images/cloud/cloud1.png"),
	_T("images/cloud/cloud2.png"),
	_T("images/cloud/cloud3.png"),
	_T("images/cloud/cloud4.png"),
	_T("images/cloud/cloud5.png"),
	_T("images/cloud/cloud6.png"),
	_T("images/cloud/cloud7.png"),
	_T("images/cloud/cloud8.png"),
	_T("images/cloud/cloud9.png"),
	_T("images/cloud/cloud10.png"),
	_T("images/cloud/cloud11.png"),
	_T("images/cloud/cloud12.png"),
	_T("images/cloud/cloud13.png"),
	_T("images/cloud/cloud14.png"),
	_T("images/cloud/cloud15.png"),
	_T("images/cloud/cloud16.png"),
	_T("images/cloud/cloud17.png"),
	_T("images/cloud/cloud18.png"),
	//MAP THINGS
	_T("images/tracks_and_cracks/crack_large01.png"),
	_T("images/tracks_and_cracks/crack_medium01.png"),
	_T("images/tracks_and_cracks/crack_small01.png"),
	_T("images/tracks_and_cracks/crack_small02.png"),
	_T("images/tracks_and_cracks/oilstain01.png"),
	_T("images/tracks_and_cracks/oilstain02.png"),
	_T("images/tracks_and_cracks/track_large.png"),
	_T("images/tracks_and_cracks/track_med.png"),
	_T("images/tracks_and_cracks/track_small.png"),
	//FULL CLOUD
	_T("images/cloud.png"),
	//TANK TURRET
	_T("images/turret_fire.png"),
	//ENEMY TURRET
	_T("images/enemy_turret2/enemy_turret_body.png"),
	_T("images/enemy_turret2/enemy_turret_top.png"),
	_T("images/enemy_flying/coptersmall0001.png"),
	_T("images/enemy_flying/coptersmall0002.png"),
	_T("images/enemy_flying/coptersmall0003.png"),
	_T("images/enemy_flying/coptersmall0004.png"),
	_T("images/horizontal_enemy/horiz0001.png"),
	_T("images/horizontal_enemy/horiz0002.png"),
	_T("images/horizontal_enemy/horiz0003.png"),
	_T("images/horizontal_enemy/horiz0004.png"),
	_T("images/horizontal_enemy/horiz0005.png"),
	_T("images/vertical_enemy/vert_enemy0001.png"),
	_T("images/vertical_enemy/vert_enemy0002.png"),
	_T("images/vertical_enemy/vert_enemy0003.png"),
	_T("images/vertical_enemy/vert_enemy0004.png"),
	_T("images/vertical_enemy/vert_enemy0005.png"),
	//MOUSECURSOR
	_T("images/crosshair.png"),
	//
	_T("images/explosion1.png"),
	//BULLETS
	_T("images/bullet1.png"),
	_T("images/bullets/enemybullet.png"),
	_T("images/bullets/laserblue.png"),
	//DEBUG STUFF
	_T("images/arrowimg.png"),
	_T("images/testfont.png"),
	_T("images/200x200x4x4.png"),
	_T("images/white.png"),
	_T("images/tinywhite.png"),
	//HUD STUFF
	_T("images/hud/right_hud.png"),
	_T("images/hud/multiplier_bar.png"),
	//POWERUP STUFF
	_T("images/newpowerups/arrow_map.png"),
	_T("images/newpowerups/flame_map.png"),
	_T("images/newpowerups/bullet_map.png"),
	_T("images/newpowerups/laser_map.png"),
	//SCREENS
	_T("images/screens/title_screen.png"),
	_T("images/screens/death_screen.png")
};

#endif
