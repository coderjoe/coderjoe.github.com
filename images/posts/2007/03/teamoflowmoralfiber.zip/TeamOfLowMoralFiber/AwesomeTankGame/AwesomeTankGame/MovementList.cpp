#include "stdafx.h"
#include "MovementList.h"


// Keeps track of the movements and performs the movements
MovementList::MovementList() {
	m_counter = 0;
	m_currentIndex = 0;
	m_done = false;
}

MovementList::~MovementList() {
	for( unsigned int i = 0; i < m_list.size(); i++ ) {

		for( unsigned int j = 0; j < m_list[i]->movements.size(); j++ ) {
			Movement * m = m_list[i]->movements[j];
			delete m;
			m = NULL;
		}

		MovementInfo * mi = m_list[i];
		mi->movements.clear();
		delete mi;
		mi = NULL;
	}
	m_list.clear();
}

// Creates a new list of movements
void MovementList::newSet() {
	m_list.push_back( new MovementInfo() );
}

void MovementList::setDuration( int d ) {
	if( m_list.size() > 0 ) {
		m_list[ m_list.size()-1 ]->duration = d;
	}
}

// Adds new movement to list
void MovementList::addMovement( Movement * m ) {
	if( m_list.size() > 0 ) {
		m_list[ m_list.size()-1 ]->movements.push_back(m);
	}
}

// Does the movements
void MovementList::doMovements() {
	if( m_currentIndex < (int)m_list.size() ) {
		
		MovementInfo * moveList = m_list[m_currentIndex];

		if( m_counter == 0 ) {
			for( unsigned int m = 0; m < moveList->movements.size(); m++ ) {
				moveList->movements[m]->initMove();
			}
		}

		for( unsigned int m = 0; m < moveList->movements.size(); m++ ) {
			moveList->movements[m]->move();
		}

		m_counter++;
		if( m_counter >= moveList->duration ) {
			m_counter = 0;
			m_currentIndex++;

			if( m_currentIndex >= (int)m_list.size() ) {
				m_currentIndex = 0;
				m_done = true;
			}
		}

	}
}

// When finished
bool MovementList::isDone() {
	return m_done;
}
