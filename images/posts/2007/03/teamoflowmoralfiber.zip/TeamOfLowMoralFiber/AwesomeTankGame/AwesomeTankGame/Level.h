/*
 * The leve loads and manages the LevelMaps and LevelActors and ticks through them
 * drawing them in the correct order
 */
#ifndef _LEVEL_H_
#define _LEVEL_H_

#include "LevelActors.h"
#include "LevelMap.h"
#include <string>
#include <iostream>
#include <fstream>
#include <vector>

class Level {
public:
	// Constructor takes in level file name
	// see level1.txt for example
	Level( std::string file );
	~Level();

	//tick the level layers and enemies
	void tick();
	//draw stuff below the player
	void drawBelow();
	//draw stuff above the player
	void drawAbove();

	//get the speed of the layer right below the player
	int getSpeed();
private:
	int			m_enemyLayer; //the enemy layer index
	int			m_playerLayer; //the player layer index
	std::vector< LevelMap * >		m_mapLayers; //the layers of scenery
	std::vector< LevelActors * >	m_actorFiles; //the actor list
};

#endif