#include "stdafx.h"
#include "SinTable.h"
#include "d3dx9.h"

SinTable::SinTable(void)
{
	sinTable.reserve( 361 );
	cosTable.reserve( 361 );

	for( int i = 0; i < 360; i++ ){
		sinTable.push_back( sin(D3DXToRadian(i)) );
		cosTable.push_back( cos(D3DXToRadian(i)) );
	}
}

SinTable::~SinTable(void)
{
}

std::vector<float> SinTable::getSinTable(){
	return sinTable;
}

std::vector<float> SinTable::getCosTable(){
	return cosTable;
}
