#include "Powerup.h"
#include "GFXManager.h"
#include "TextureManager.h"
#include "GameEngine.h"

Powerup::Powerup( powerup_t ptype, float x, float y )
{
	// Setup
	type = neutral;
	pow_type = ptype;
	obj_type = powerup;

	// Hit box
	points.push_back(D3DXVECTOR2(7,7));
	points.push_back(D3DXVECTOR2(41,7));
	points.push_back(D3DXVECTOR2(41,41));
	points.push_back(D3DXVECTOR2(7,41));


	draw_index = 0;
	indexdx = 1;

	switch( pow_type ){
		case speed:
			texture = TEX_POW_SPEED;
			break;
		case fire:
			texture = TEX_POW_FLAME;
			break;
		case tri:
			texture = TEX_POW_TRI;
			break;
		case laser:
			texture = TEX_POW_LASER;
			break;
	}

	dy = GAMEENGINE.getLevel()->getSpeed();
	setPosition( D3DXVECTOR2( x, y ) );
}

Powerup::~Powerup(void)
{
}

void Powerup::draw(){
	float onewidth = static_cast<float>(TEXTUREMANAGER.getTextureInfo(texture).Width) / 6;
	RECT offset;
	offset.top = 0;
	offset.bottom = TEXTUREMANAGER.getTextureInfo(texture).Height;
	offset.left = draw_index * onewidth;
	offset.right = (draw_index + 1) * onewidth;
	GFXMANAGER.draw( TEXTUREMANAGER.getTexture(texture), &offset, NULL, &m_position );
}

void Powerup::tick(){
	// Run animation
	static int counter = 0;

	if( counter == POW_DRAW_DELAY ){

		if( draw_index == 5 ){
			indexdx = -1;
		}
		if( draw_index == 0 ){
			indexdx = 1;
		}
		draw_index += indexdx;
		counter %= POW_DRAW_DELAY;
	}
	counter++;


	m_position.y += dy;
	if( m_position.y > GAME_HEIGHT || collided ){
		GAMEENGINE.removeActor( this );
		return;
	}

	GAMEENGINE.registerCollidable( this );
}

void Powerup::setDy( int v ){
	dy = v;
}

powerup_t Powerup::getPowType(){
	return pow_type;
}

void Powerup::setCollided( Collidable* other ){
	// Disappear if a tank hit us
	object_t otype = other->getObjectType();
	if( otype == tank ){
		collided = true;		
	}
}


int Powerup::getWidth() {
	return TEXTUREMANAGER.getTextureInfo( texture ).Width / 6;
}

int Powerup::getHeight() {
	return TEXTUREMANAGER.getTextureInfo( texture ).Height;
}