#ifndef _TEXTUREMANAGER_H_
#define _TEXTUREMANAGER_H_

#include "Singleton.h"
#include "TextureList.h"
#include "D3DManager.h"
#include "d3dx9.h"
#include <vector>

#define TEXTUREMANAGER TextureManager::Instance()

// Holds all the textures and allows the Actors to access them.
// Manages when switching to full screen
class TextureManager : public Singleton<TextureManager> {
	friend class Singleton<TextureManager>;
protected:
	TextureManager();
	~TextureManager();
public:
	// Basically for switching to full screen.  kills then loads again
	void loadTextures();
	void killTextures();

	// Retrieve a texture based on its index defined in texturelist.h
	LPDIRECT3DTEXTURE9 getTexture( int index );
	D3DXIMAGE_INFO getTextureInfo( int index );
private:
	// The textures
	std::vector< LPDIRECT3DTEXTURE9 >	m_vTextures;
	// Their info
	std::vector< D3DXIMAGE_INFO >		m_vTextureInfo;
	bool								m_bTexturesLoaded;
};

#endif