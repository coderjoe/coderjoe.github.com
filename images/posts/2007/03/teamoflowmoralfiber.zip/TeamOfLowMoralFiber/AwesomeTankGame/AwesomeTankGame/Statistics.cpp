#include "Statistics.h"

// Constructor for Statistics, which sets all the variables
Statistics::Statistics() {
	m_frameCount = 0;
	m_framesPerSecond = 0;
	m_currentClock = 0;
	m_checkClock = 0;

	m_interval = 1;
}

Statistics::~Statistics() {
}

// Calculates the frame rate
void Statistics::calculateFrameRate() {
	m_checkClock = clock();
	m_frameCount++;
	
	if( m_checkClock >= ( m_currentClock + 500 ) ) {
		m_currentClock = m_checkClock;
		m_framesPerSecond = m_frameCount * 2;
		m_frameCount = 0;
	}
}

// Returns the frames per second value
int Statistics::getFrameRate() {
	return m_framesPerSecond;
}