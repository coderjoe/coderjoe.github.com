/*
 * EnemyBullet is a bullet sublcass for the bullets which enemies spawn
 * it collides with good guys (the player) and looks different.
 */
#ifndef _ENEMYBULLET_H_
#define _ENEMYBULLET_H_

#include "Bullet.h"

class EnemyBullet : public Bullet {
public:
	/*Constructor
	 * Arguments:
	 *	x - The x position of the bullet
	 *  y - the y position of the bullet
	 * rot - the rotation of the bullet (direction of travel)
	 * damage_mult - the damage multiplier for the bullet
	 */
	EnemyBullet(float x, float y, float rot, int damage_mult );

	//destructo
	~EnemyBullet();

	//Set collided override from collidable
	//sets to collide only with the friendies
	virtual void setCollided( Collidable * other );
private:
};

#endif