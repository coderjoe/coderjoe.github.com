/*
 * PowerUpFactory generates a powerup at a location based on randomness
 */
#ifndef _POWERUPFACTORY_H_
#define _POWERUPFACTORY_H_

#include "Actor.h"
#include <string>

class PowerUpFactory {
public:
	/*
	 * Create a powerup at a location
	 * arguments:
	 *	x - the x location
	 *  y - the y location
	 */
	static void CreatePowerUpAt( int x, int y );
};
#endif