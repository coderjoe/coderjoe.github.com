#pragma once
#include "Collidable.h"

// How fast powerups animate
#define POW_DRAW_DELAY 13

// Types of powerup
enum powerup_t { none, tri, fire, speed, laser };

class Powerup :
	public Collidable
{
public:
	// Create a powerup with location and type
	Powerup( powerup_t type = speed, float x = 10, float y = 10 );
	~Powerup(void);

	// Get what type of powerup this is
	powerup_t getPowType();

	// See Actor.h
	void draw();
	void tick();
	int getWidth();
	int getHeight();

	// Set the velocity the powerup moves (usually from level speed)
	void setDy( int v );

	void setCollided( Collidable* other );

private:
	powerup_t	pow_type;

	// Draw stuff
	int			draw_index;
	int			indexdx;
	int			texture;

	int			dy;
};
