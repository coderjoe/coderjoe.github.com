/* 
 * Spawn actors based on the identifiers they set
 */
#ifndef _ACTORFACTORY_H_
#define _ACTORFACTORY_H_

#include "Actor.h"
#include <string>

class ActorFactory {
public:
	//Create an actor at the location
	//	x-x location
	//	y-y location
	static Actor * CreateActorAt( std::string type, int x, int y );
};
#endif