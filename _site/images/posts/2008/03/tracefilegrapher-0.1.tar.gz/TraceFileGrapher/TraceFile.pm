#
#   TraceFileGrapher creates hierarchial graphs of Oracle trace files.
#   It has only been tested on trace files for Oracle 10.2.0.x.
#
#   Copyright 2008 Joe Bauser <coderjoe@coderjoe.net>
#
#   This file is part of TraceFileGrapher.
#
#   TraceFileGrapher is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
package TraceFile;
use strict;

sub new {
	my $self = {};

	#file information
	$self->{fileName} = undef;
	$self->{dateTime} = undef;
	$self->{oracleVersion} = undef;
	$self->{operatingSystem} = undef;
	$self->{cpu} = undef;
	$self->{processAffinity} = undef;
	$self->{memory} = undef;
	$self->{instanceName} = undef;

	#file sections
	$self->{stackTrace} = undef;
	$self->{plsqlTrace} = undef;

	bless($self);
	return $self;
}

sub stackTrace {
	my( $self ) = shift;
	return @{$self->{stackTrace}};
}

sub plsqlTrace {
	my( $self ) = shift;
	return @{$self->{plsqlTrace}};
}

sub load {
	my( $self ) = shift;
	$self->{fileName} = shift;

	my $plsqlTrace = 0;
	my $stackTrace = 0;
	my $finished = 0;
	my @lines = [];
	my @stackTrace = [];
	my @plsqlTrace = [];
	my $call = "";

	open( TRACEFILE, "<$self->{fileName}" ) or die "Could not open trace file \"".$self->{fileName}."\"";
	@lines = <TRACEFILE>;

	$self->{dateTime} = $lines[1];
	$self->{oracleVersion} = $lines[4];
	$self->{operatingSystem} = $lines[5];
	$self->{cpu} = $lines[6];
	$self->{processAffinity} = $lines[7];
	$self->{memory} = $lines[8];
	$self->{instanceName} = $lines[9];

	for( my $i = 0; $i < $#lines && ! $finished; $i++ ) {

		if($plsqlTrace && $lines[$i] =~ /^[a-zA-Z0-9]+\s+(\d+)\s+(.+)$/) {
			$call = $2 . " Line " . $1;
			push( @plsqlTrace, $call );
		} elsif($stackTrace && $lines[$i] =~ /^(\w+[()]{2}\+\d+).+$/) {
			$call = $1;
			push( @stackTrace, $call );
		}

		if( $lines[$i] =~ /--------------------- Binary Stack Dump ---------------------/ ) {
			$finished = 1;
		} elsif( $lines[$i] =~ /----- PL\/SQL Call Stack -----/) {
			$plsqlTrace = 1;
			$stackTrace = 0;
		} elsif( $lines[$i] =~ /----- Call Stack Trace -----/ ) {
			$plsqlTrace = 0;
			$stackTrace = 1;
		}
	}

	@{$self->{plsqlTrace}} = reverse(@plsqlTrace);
	@{$self->{stackTrace}} = reverse(@stackTrace);
}

1;
