#!/usr/bin/perl -w
#
#   TraceFileGrapher creates hierarchial graphs of Oracle trace files.
#   It has only been tested on trace files for Oracle 10.2.0.x.
#
#   Copyright 2008 Joe Bauser <coderjoe@coderjoe.net>
#
#   This file is part of TraceFileGrapher.
#
#   TraceFileGrapher is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
use TraceFile;
use TraceTree;
use Graph::Easy;
use Getopt::Std;

sub getFilesList {
	my($directory) = shift;
	opendir(DIR, $directory);
	my @fileNames = grep(/\.trc$/,readdir(DIR));
	closedir(DIR);

	return @fileNames;
}

sub parseStackTrace {
	my $plsqlStackTrace = shift;
	my $showLoops = shift;
	my $file = shift;
	my $treeHead = shift;
	my $currentNode = $treeHead;
	my @stackTrace = undef;
	if( $plsqlStackTrace ) {
		@stackTrace = $file->plsqlTrace();
	} else {
		@stackTrace = $file->stackTrace();
	}
	my $coreDumped = 0;

	for( my $i = 0; $i < $#stackTrace && ! $coreDumped ; $i++ ) {
		my $label = $stackTrace[$i];
		if( !$showLoops ) {
			$label = $label." (Call " . ($i+1) . ")";
		}

		if( ($stackTrace[$i] =~ /sigacthandler/) ||
		    ($stackTrace[$i] =~ /ssexhd/) ||
		    ($stackTrace[$i] =~ /ksedmp/) ) {
		    $coreDumped = 1;
		}

		if( $coreDumped ) {
			$currentNode->addChildNode( TreeNode->new( $file->{fileName}, [] ) );
		} else {
			if( ! $currentNode->hasChild( $label ) ) {
				$currentNode->addChildNode( TreeNode->new( $label, [] ) );
			}

			$currentNode = $currentNode->getChild( $label );
		}
	}

	@dataArr = $currentNode->data();
	push(@dataArr, $file);
}

sub treeToGraphviz {
	my $graph = shift;
	my $currentNode = shift;
	my $previousNode = shift;

	if( defined($currentNode) ) {
		my @children = $currentNode->childLabels();

		#print $currentNode->label() . " with " . @children . " children.\n";
		my $node = $graph->add_node( $currentNode->label() );

		#if we have a previous node then we're not the head
		if( $previousNode ) {
			#set our rank
			$graph->add_edge_once( $previousNode->label(), $currentNode->label() );
			#$node->set_attribute('fill','yellow');
		} else {
			#we're the head, rank it same as tail and make it green
			$node->set_attribute('rank','same');
			$node->set_attribute('fill','lawngreen');
		}

		if( $currentNode->isLeafNode() ) {
			#we're tail nodes, rank same as head "same" and make us red
			$node->set_attribute('fill', 'orangered');
			$node->set_attribute('rank','same');
		}

		for $label ( @children ) {
			treeToGraphviz( $graph, $currentNode->getChild($label), $currentNode );
		}
	}
}

sub usage() {
	print STDERR "usage: $0 [-hl] [-f format] [-d directory] [-o filename]
  -h        : this (help) message
  -l        : allow loops in output graph
  -p        : Use the PL/SQL Stack trace as opposed to the execution stack
  -d dir    : path to a directory containing trace files
  -f format : graphviz format type
  -o file   : output filename

  example: $0 -d ./tracefiles/ -f png -o tracegraph.png
";
	exit;
}

sub parseOptions {
	my %options = ();
	getopts("lphf:d:o:", \%options);

	if( !$options{"o"} || !$options{"f"} || !$options{"d"} || $options{"h"} ) {
		usage();
	}

	return %options;
}



sub main {
	my %options = parseOptions();
	my @filesList = getFilesList($options{"d"});
	my $head = TreeNode->new("HEAD");
	my $graph = Graph::Easy->new();

	for $f (@filesList) {
		my $file = TraceFile->new();
		$file->load( $options{"d"} . $f );
		parseStackTrace( $options{"p"}, $options{"l"}, $file, $head );
	}

	@headChildren = $head->childLabels();
	for $label (@headChildren) {
		treeToGraphviz($graph, $head->getChild($label));
	}

	# Graphviz:
        my $graphviz = $graph->as_graphviz();

        open $DOT, "|dot -T".$options{"f"}." -o ".$options{"o"} or die ("Cannot open pipe to dot: $!");
        print $DOT $graphviz;
        close $DOT;
}
main();


