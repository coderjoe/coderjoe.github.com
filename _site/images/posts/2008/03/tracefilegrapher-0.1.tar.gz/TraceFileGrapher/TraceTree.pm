#
#   TraceFileGrapher creates hierarchial graphs of Oracle trace files.
#   It has only been tested on trace files for Oracle 10.2.0.x.
#
#   Copyright 2008 Joe Bauser <coderjoe@coderjoe.net>
#
#   This file is part of TraceFileGrapher.
#
#   TraceFileGrapher is free software: you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation, either version 3 of the License, or
#   (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
package TreeNode;
use strict;

sub new {
	my $self = {};
	my $bogus = shift; #shift off the passed object reference

	my $newLabel = shift;
	my $data = shift;

	$self->{label} = undef;
	$self->{label} = $newLabel if defined $newLabel;

	$self->{data} = undef;
	$self->{data} = $data if defined $data;

	$self->{children} = () ;
	bless $self;
	return $self;
}

sub label {
	my $self = shift;
	my $data = shift;
	$self->{label} = $data if defined $data;
	return $self->{label};
}

sub data {
	my $self = shift;
	my $data = shift;
	$self->{data} = $data if defined $data;
	return $self->{data};
}

sub toString {
	my $self = shift;
	return "TreeNode<".$self->label() . "( " . $self->data() . " )>";
}

sub addChildNode {
	my $self = shift;
	my $node = shift;

	$self->{children}{ $node->label() } = $node if defined $node;
}

sub childLabels {
	my $self = shift;
	return keys( %{$self->{children}} );
}

sub getChild {
	my $self = shift;
	my $label = shift;
	return $self->{children}{ $label };
}

sub hasChild {
	my $self = shift;
	my $label = shift;

	return defined($self->getChild( $label ));
}

sub isLeafNode {
	my $self = shift;
	return (scalar($self->childLabels()) == 0);
}

1;
