Group Members: Joseph Bauser, Geoff Brown

Website: http://www.coderjoe.net/archive/category/cg2-journal/
